import settingsGradle from '../../android/settings.gradle.kts?raw';
import rootBuildGradle from '../../android/build.gradle.kts?raw';
import libsVersionsToml from '../../android/gradle/libs.versions.toml?raw';
import appBuildGradle from '../../android/app/build.gradle.kts?raw';
import androidManifest from '../../android/app/src/main/AndroidManifest.xml?raw';
import stringsXml from '../../android/app/src/main/res/values/strings.xml?raw';
import themesXml from '../../android/app/src/main/res/values/themes.xml?raw';
import mainActivityKt from '../../android/app/src/main/java/com/smartcalculator/app/MainActivity.kt?raw';
import vaultPhotoEntityKt from '../../android/app/src/main/java/com/smartcalculator/app/data/VaultPhotoEntity.kt?raw';
import vaultPhotoDaoKt from '../../android/app/src/main/java/com/smartcalculator/app/data/VaultPhotoDao.kt?raw';
import vaultDatabaseKt from '../../android/app/src/main/java/com/smartcalculator/app/data/VaultDatabase.kt?raw';
import secretCodeStoreKt from '../../android/app/src/main/java/com/smartcalculator/app/storage/SecretCodeStore.kt?raw';
import vaultFileManagerKt from '../../android/app/src/main/java/com/smartcalculator/app/storage/VaultFileManager.kt?raw';
import calculatorEngineKt from '../../android/app/src/main/java/com/smartcalculator/app/ui/CalculatorEngine.kt?raw';
import vaultViewModelKt from '../../android/app/src/main/java/com/smartcalculator/app/ui/VaultViewModel.kt?raw';
import calculatorScreenKt from '../../android/app/src/main/java/com/smartcalculator/app/ui/CalculatorScreen.kt?raw';
import vaultScreensKt from '../../android/app/src/main/java/com/smartcalculator/app/ui/VaultScreens.kt?raw';
import themeKt from '../../android/app/src/main/java/com/smartcalculator/app/ui/theme/Theme.kt?raw';

export interface AndroidSourceFile {
  path: string;
  label: string;
  category: 'App & UI' | 'Storage & Room' | 'Gradle & Manifest';
  content: string;
}

export const ANDROID_SOURCE_FILES: AndroidSourceFile[] = [
  {
    path: 'app/src/main/java/com/smartcalculator/app/MainActivity.kt',
    label: 'MainActivity.kt',
    category: 'App & UI',
    content: mainActivityKt,
  },
  {
    path: 'app/src/main/java/com/smartcalculator/app/ui/CalculatorEngine.kt',
    label: 'CalculatorEngine.kt',
    category: 'App & UI',
    content: calculatorEngineKt,
  },
  {
    path: 'app/src/main/java/com/smartcalculator/app/ui/CalculatorScreen.kt',
    label: 'CalculatorScreen.kt',
    category: 'App & UI',
    content: calculatorScreenKt,
  },
  {
    path: 'app/src/main/java/com/smartcalculator/app/ui/VaultScreens.kt',
    label: 'VaultScreens.kt',
    category: 'App & UI',
    content: vaultScreensKt,
  },
  {
    path: 'app/src/main/java/com/smartcalculator/app/ui/VaultViewModel.kt',
    label: 'VaultViewModel.kt',
    category: 'App & UI',
    content: vaultViewModelKt,
  },
  {
    path: 'app/src/main/java/com/smartcalculator/app/ui/theme/Theme.kt',
    label: 'Theme.kt',
    category: 'App & UI',
    content: themeKt,
  },
  {
    path: 'app/src/main/java/com/smartcalculator/app/storage/VaultFileManager.kt',
    label: 'VaultFileManager.kt',
    category: 'Storage & Room',
    content: vaultFileManagerKt,
  },
  {
    path: 'app/src/main/java/com/smartcalculator/app/storage/SecretCodeStore.kt',
    label: 'SecretCodeStore.kt',
    category: 'Storage & Room',
    content: secretCodeStoreKt,
  },
  {
    path: 'app/src/main/java/com/smartcalculator/app/data/VaultPhotoEntity.kt',
    label: 'VaultPhotoEntity.kt',
    category: 'Storage & Room',
    content: vaultPhotoEntityKt,
  },
  {
    path: 'app/src/main/java/com/smartcalculator/app/data/VaultPhotoDao.kt',
    label: 'VaultPhotoDao.kt',
    category: 'Storage & Room',
    content: vaultPhotoDaoKt,
  },
  {
    path: 'app/src/main/java/com/smartcalculator/app/data/VaultDatabase.kt',
    label: 'VaultDatabase.kt',
    category: 'Storage & Room',
    content: vaultDatabaseKt,
  },
  {
    path: 'app/build.gradle.kts',
    label: 'app/build.gradle.kts',
    category: 'Gradle & Manifest',
    content: appBuildGradle,
  },
  {
    path: 'app/src/main/AndroidManifest.xml',
    label: 'AndroidManifest.xml',
    category: 'Gradle & Manifest',
    content: androidManifest,
  },
  {
    path: 'gradle/libs.versions.toml',
    label: 'libs.versions.toml',
    category: 'Gradle & Manifest',
    content: libsVersionsToml,
  },
  {
    path: 'build.gradle.kts',
    label: 'build.gradle.kts',
    category: 'Gradle & Manifest',
    content: rootBuildGradle,
  },
  {
    path: 'settings.gradle.kts',
    label: 'settings.gradle.kts',
    category: 'Gradle & Manifest',
    content: settingsGradle,
  },
  {
    path: 'app/src/main/res/values/strings.xml',
    label: 'strings.xml',
    category: 'Gradle & Manifest',
    content: stringsXml,
  },
  {
    path: 'app/src/main/res/values/themes.xml',
    label: 'themes.xml',
    category: 'Gradle & Manifest',
    content: themesXml,
  },
];
