import React, { useEffect, useRef, useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Download,
  RotateCcw,
  X,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import { formatBytes } from '../utils/vaultStorage';

export interface ViewerPhotoItem {
  id: string;
  url: string;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
  width: number;
  height: number;
  createdAt: number;
}

interface FullScreenPhotoModalProps {
  photos: ViewerPhotoItem[];
  initialIndex: number;
  onClose: () => void;
}

export const FullScreenPhotoModal: React.FC<FullScreenPhotoModalProps> = ({
  photos,
  initialIndex,
  onClose,
}) => {
  const [index, setIndex] = useState(() =>
    Math.min(Math.max(initialIndex, 0), Math.max(photos.length - 1, 0))
  );
  const [scale, setScale] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const dragRef = useRef<{ active: boolean; startX: number; startY: number; origX: number; origY: number }>({
    active: false,
    startX: 0,
    startY: 0,
    origX: 0,
    origY: 0,
  });

  const current = photos[index];

  const resetZoom = () => {
    setScale(1);
    setOffset({ x: 0, y: 0 });
  };

  const goPrev = () => {
    if (photos.length <= 1) return;
    resetZoom();
    setIndex((prev) => (prev - 1 + photos.length) % photos.length);
  };

  const goNext = () => {
    if (photos.length <= 1) return;
    resetZoom();
    setIndex((prev) => (prev + 1) % photos.length);
  };

  const zoomIn = () => {
    setScale((prev) => Math.min(4, Number((prev + 0.5).toFixed(2))));
  };

  const zoomOut = () => {
    setScale((prev) => {
      const next = Math.max(1, Number((prev - 0.5).toFixed(2)));
      if (next === 1) setOffset({ x: 0, y: 0 });
      return next;
    });
  };

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      else if (e.key === 'ArrowLeft') goPrev();
      else if (e.key === 'ArrowRight') goNext();
      else if (e.key === '+' || e.key === '=') zoomIn();
      else if (e.key === '-') zoomOut();
      else if (e.key === '0') resetZoom();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  });

  if (!current) return null;

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    if (e.deltaY < 0) zoomIn();
    else zoomOut();
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    if (scale <= 1) return;
    dragRef.current = {
      active: true,
      startX: e.clientX,
      startY: e.clientY,
      origX: offset.x,
      origY: offset.y,
    };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!dragRef.current.active || scale <= 1) return;
    setOffset({
      x: dragRef.current.origX + (e.clientX - dragRef.current.startX),
      y: dragRef.current.origY + (e.clientY - dragRef.current.startY),
    });
  };

  const handlePointerUp = () => {
    dragRef.current.active = false;
  };

  const handleDownloadCurrent = () => {
    const a = document.createElement('a');
    a.href = current.url;
    a.download = current.fileName;
    a.click();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Full screen photo viewer"
      className="fixed inset-0 z-50 bg-black/95 text-white flex flex-col select-none"
    >
      {/* Top Controls */}
      <div className="h-16 px-4 sm:px-6 flex items-center justify-between border-b border-white/10 shrink-0">
        <div className="font-mono-tabular text-sm font-medium text-slate-200 whitespace-nowrap">
          {index + 1} / {photos.length}
        </div>

        <div className="flex items-center gap-1 sm:gap-2">
          <button
            type="button"
            onClick={zoomOut}
            disabled={scale <= 1}
            aria-label="Zoom out"
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl hover:bg-white/10 disabled:opacity-40 transition-colors"
          >
            <ZoomOut className="w-5 h-5" />
          </button>
          <span className="font-mono-tabular text-xs text-slate-300 w-12 text-center">
            {Math.round(scale * 100)}%
          </span>
          <button
            type="button"
            onClick={zoomIn}
            disabled={scale >= 4}
            aria-label="Zoom in"
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl hover:bg-white/10 disabled:opacity-40 transition-colors"
          >
            <ZoomIn className="w-5 h-5" />
          </button>
          {scale > 1 && (
            <button
              type="button"
              onClick={resetZoom}
              aria-label="Reset zoom"
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl hover:bg-white/10 transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          )}
          <button
            type="button"
            onClick={handleDownloadCurrent}
            aria-label="Export photo"
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl hover:bg-white/10 transition-colors"
          >
            <Download className="w-5 h-5" />
          </button>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close viewer"
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Image Viewport */}
      <div
        className="relative flex-1 overflow-hidden flex items-center justify-center p-4"
        onWheel={handleWheel}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onDoubleClick={() => {
          if (scale > 1) resetZoom();
          else setScale(2.2);
        }}
      >
        {photos.length > 1 && (
          <button
            type="button"
            onClick={goPrev}
            aria-label="Previous photo"
            className="absolute left-3 sm:left-5 z-10 min-h-[48px] min-w-[48px] flex items-center justify-center rounded-full bg-black/60 hover:bg-black/80 border border-white/15 text-white transition-colors"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
        )}

        <img
          src={current.url}
          alt={current.fileName}
          draggable={false}
          referrerPolicy="no-referrer"
          style={{
            transform: `translate3d(${offset.x}px, ${offset.y}px, 0) scale(${scale})`,
            cursor: scale > 1 ? 'grab' : 'zoom-in',
          }}
          className="max-w-full max-h-full object-contain transition-transform duration-150 ease-out"
        />

        {photos.length > 1 && (
          <button
            type="button"
            onClick={goNext}
            aria-label="Next photo"
            className="absolute right-3 sm:right-5 z-10 min-h-[48px] min-w-[48px] flex items-center justify-center rounded-full bg-black/60 hover:bg-black/80 border border-white/15 text-white transition-colors"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        )}
      </div>

      {/* Bottom Metadata Bar */}
      <div className="px-4 sm:px-6 py-3 border-t border-white/10 flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-xs text-slate-300">
        <span className="font-medium text-white truncate max-w-[240px]">{current.fileName}</span>
        {current.width > 0 && current.height > 0 && (
          <>
            <span aria-hidden="true">·</span>
            <span className="font-mono-tabular">
              {current.width} × {current.height}
            </span>
          </>
        )}
        <span aria-hidden="true">·</span>
        <span className="font-mono-tabular">{formatBytes(current.sizeBytes)}</span>
        <span aria-hidden="true">·</span>
        <span>{new Date(current.createdAt).toLocaleDateString()}</span>
      </div>
    </div>
  );
};
