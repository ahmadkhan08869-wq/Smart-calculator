import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  Check,
  CheckCircle2,
  Code2,
  Download,
  ImagePlus,
  Images,
  KeyRound,
  Lock,
  Moon,
  ShieldCheck,
  Sun,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import {
  buildVaultBackupBlob,
  deleteAllVaultPhotos,
  deleteVaultPhotosByIds,
  formatBytes,
  getAllVaultPhotos,
  getSecretCode,
  inspectBackupRequiresPassphrase,
  prepareStagedPhotos,
  restoreVaultFromBackupFile,
  saveStagedPhotosToVault,
  setSecretCode,
  StagedPhotoPreview,
  StoredVaultPhoto,
} from '../utils/vaultStorage';
import { FullScreenPhotoModal, ViewerPhotoItem } from './FullScreenPhotoModal';
import { AndroidSourceViewer } from './AndroidSourceViewer';

type VaultSection =
  | 'menu'
  | 'preview'
  | 'gallery'
  | 'delete'
  | 'code'
  | 'backup'
  | 'android';

interface VaultViewProps {
  isDarkTheme: boolean;
  onToggleTheme: () => void;
  onLock: () => void;
}

interface HydratedPhoto extends ViewerPhotoItem {
  sha256Hash: string;
}

export const VaultView: React.FC<VaultViewProps> = ({
  isDarkTheme,
  onToggleTheme,
  onLock,
}) => {
  const [section, setSection] = useState<VaultSection>('menu');
  const [photos, setPhotos] = useState<HydratedPhoto[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isBusy, setIsBusy] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  // Add Photos staging preview
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [stagedPhotos, setStagedPhotos] = useState<StagedPhotoPreview[]>([]);

  // Gallery full-screen viewer
  const [viewerIndex, setViewerIndex] = useState<number | null>(null);

  // Delete selection state
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [showDeleteAllConfirm, setShowDeleteAllConfirm] = useState(false);

  // Change secret code form
  const [currentCodeInput, setCurrentCodeInput] = useState('');
  const [newCodeInput, setNewCodeInput] = useState('');
  const [confirmCodeInput, setConfirmCodeInput] = useState('');
  const [codeError, setCodeError] = useState<string | null>(null);

  // Export & Restore state
  const [exportPassphrase, setExportPassphrase] = useState('');
  const [restoreFile, setRestoreFile] = useState<File | null>(null);
  const [restoreNeedsPassphrase, setRestoreNeedsPassphrase] = useState(false);
  const [restorePassphrase, setRestorePassphrase] = useState('');
  const restoreInputRef = useRef<HTMLInputElement | null>(null);

  const objectUrlsRef = useRef<string[]>([]);

  const hydrateFromDb = async () => {
    setIsLoading(true);
    try {
      const stored: StoredVaultPhoto[] = await getAllVaultPhotos();
      // Revoke old object URLs
      objectUrlsRef.current.forEach((u) => URL.revokeObjectURL(u));
      const newUrls: string[] = [];

      const hydrated: HydratedPhoto[] = stored.map((item) => {
        const blob = new Blob([item.data], { type: item.mimeType || 'image/jpeg' });
        const url = URL.createObjectURL(blob);
        newUrls.push(url);
        return {
          id: item.id,
          url,
          fileName: item.fileName,
          mimeType: item.mimeType,
          sizeBytes: item.sizeBytes,
          width: item.width,
          height: item.height,
          createdAt: item.createdAt,
          sha256Hash: item.sha256Hash,
        };
      });

      objectUrlsRef.current = newUrls;
      setPhotos(hydrated);
    } catch (err) {
      setStatusMessage({
        type: 'error',
        text: err instanceof Error ? err.message : 'Unable to load saved photos.',
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    void hydrateFromDb();
    return () => {
      objectUrlsRef.current.forEach((u) => URL.revokeObjectURL(u));
      objectUrlsRef.current = [];
    };
  }, []);

  // Clean up staged preview URLs on unmount
  useEffect(() => {
    return () => {
      stagedPhotos.forEach((s) => URL.revokeObjectURL(s.previewUrl));
    };
  }, [stagedPhotos]);

  const totalSize = useMemo(
    () => photos.reduce((acc, p) => acc + p.sizeBytes, 0),
    [photos]
  );

  const existingHashes = useMemo(
    () => new Set(photos.map((p) => p.sha256Hash)),
    [photos]
  );

  const triggerPhotoPicker = () => {
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
      fileInputRef.current.click();
    }
  };

  const handleFilesSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setIsBusy(true);
    setStatusMessage(null);
    try {
      const prepared = await prepareStagedPhotos(files, existingHashes);
      if (prepared.length === 0) {
        setStatusMessage({
          type: 'error',
          text: 'No supported image files were selected.',
        });
        return;
      }
      setStagedPhotos((prev) => {
        prev.forEach((p) => URL.revokeObjectURL(p.previewUrl));
        return prepared;
      });
      setSection('preview');
    } catch {
      setStatusMessage({
        type: 'error',
        text: 'Failed to read selected photos.',
      });
    } finally {
      setIsBusy(false);
    }
  };

  const handleCancelImport = () => {
    stagedPhotos.forEach((s) => URL.revokeObjectURL(s.previewUrl));
    setStagedPhotos([]);
    setSection('menu');
  };

  const handleRemoveStagedItem = (tempId: string) => {
    setStagedPhotos((prev) => {
      const target = prev.find((p) => p.tempId === tempId);
      if (target) URL.revokeObjectURL(target.previewUrl);
      const next = prev.filter((p) => p.tempId !== tempId);
      if (next.length === 0) setSection('menu');
      return next;
    });
  };

  const handleAcceptImport = async () => {
    if (stagedPhotos.length === 0) return;
    setIsBusy(true);
    try {
      const summary = await saveStagedPhotosToVault(stagedPhotos);
      stagedPhotos.forEach((s) => URL.revokeObjectURL(s.previewUrl));
      setStagedPhotos([]);
      await hydrateFromDb();
      setSection('gallery');

      const parts = [`${summary.savedCount} photo${summary.savedCount === 1 ? '' : 's'} saved to private vault`];
      if (summary.duplicateCount > 0) {
        parts.push(`${summary.duplicateCount} duplicate${summary.duplicateCount === 1 ? '' : 's'} skipped`);
      }
      setStatusMessage({
        type: 'success',
        text: parts.join(' · '),
      });
    } catch (err) {
      setStatusMessage({
        type: 'error',
        text: err instanceof Error ? err.message : 'Failed to save photos.',
      });
    } finally {
      setIsBusy(false);
    }
  };

  const toggleSelectDelete = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleDeleteSelected = async () => {
    if (selectedIds.size === 0) return;
    setIsBusy(true);
    try {
      const ids = Array.from(selectedIds);
      await deleteVaultPhotosByIds(ids);
      setSelectedIds(new Set());
      await hydrateFromDb();
      setStatusMessage({
        type: 'success',
        text: `${ids.length} photo${ids.length === 1 ? '' : 's'} permanently deleted.`,
      });
    } catch {
      setStatusMessage({ type: 'error', text: 'Could not delete selected photos.' });
    } finally {
      setIsBusy(false);
    }
  };

  const handleDeleteAllConfirm = async () => {
    setShowDeleteAllConfirm(false);
    setIsBusy(true);
    try {
      await deleteAllVaultPhotos();
      setSelectedIds(new Set());
      await hydrateFromDb();
      setStatusMessage({
        type: 'success',
        text: 'All saved photos permanently deleted from private vault.',
      });
    } catch {
      setStatusMessage({ type: 'error', text: 'Failed to delete all photos.' });
    } finally {
      setIsBusy(false);
    }
  };

  const handleChangeCodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCodeError(null);
    const activeCode = getSecretCode();

    if (currentCodeInput !== activeCode) {
      setCodeError('Current secret code is incorrect.');
      return;
    }
    if (!/^\d{4,12}$/.test(newCodeInput)) {
      setCodeError('New secret code must be 4 to 12 digits.');
      return;
    }
    if (newCodeInput !== confirmCodeInput) {
      setCodeError('New secret code and confirmation do not match.');
      return;
    }

    try {
      setSecretCode(newCodeInput);
      setCurrentCodeInput('');
      setNewCodeInput('');
      setConfirmCodeInput('');
      setSection('menu');
      setStatusMessage({
        type: 'success',
        text: 'Secret code updated. Use your new code followed by = to unlock.',
      });
    } catch (err) {
      setCodeError(err instanceof Error ? err.message : 'Unable to update secret code.');
    }
  };

  const handleExportBackup = async () => {
    if (photos.length === 0) {
      setStatusMessage({ type: 'error', text: 'Add at least one photo before exporting.' });
      return;
    }
    setIsBusy(true);
    try {
      const { blob, count } = await buildVaultBackupBlob(exportPassphrase);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      const dateSlug = new Date().toISOString().slice(0, 10);
      a.download = `smart-calculator-vault-${dateSlug}.scvault.json`;
      a.click();
      URL.revokeObjectURL(url);
      setStatusMessage({
        type: 'success',
        text: `Exported ${count} photo${count === 1 ? '' : 's'}${exportPassphrase.trim() ? ' (AES-256 encrypted)' : ''}.`,
      });
    } catch {
      setStatusMessage({ type: 'error', text: 'Failed to export backup archive.' });
    } finally {
      setIsBusy(false);
    }
  };

  const handleSelectRestoreFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setStatusMessage(null);
    try {
      const encrypted = await inspectBackupRequiresPassphrase(file);
      setRestoreFile(file);
      setRestoreNeedsPassphrase(encrypted);
      setRestorePassphrase('');
    } catch (err) {
      setRestoreFile(null);
      setStatusMessage({
        type: 'error',
        text: err instanceof Error ? err.message : 'Invalid backup file.',
      });
    }
  };

  const handleExecuteRestore = async () => {
    if (!restoreFile) return;
    setIsBusy(true);
    try {
      const summary = await restoreVaultFromBackupFile(restoreFile, restorePassphrase);
      setRestoreFile(null);
      setRestorePassphrase('');
      setRestoreNeedsPassphrase(false);
      await hydrateFromDb();
      setSection('gallery');
      const parts = [`Restored ${summary.savedCount} photo${summary.savedCount === 1 ? '' : 's'}`];
      if (summary.duplicateCount > 0) {
        parts.push(`${summary.duplicateCount} duplicate${summary.duplicateCount === 1 ? '' : 's'} skipped`);
      }
      setStatusMessage({ type: 'success', text: parts.join(' · ') });
    } catch (err) {
      setStatusMessage({
        type: 'error',
        text: err instanceof Error ? err.message : 'Restore failed.',
      });
    } finally {
      setIsBusy(false);
    }
  };

  const newPhotosInPreviewCount = stagedPhotos.filter((s) => !s.isDuplicate).length;

  return (
    <div className="min-h-dvh flex flex-col bg-[#f4f6f8] dark:bg-[#0b0f17] text-slate-900 dark:text-slate-50 transition-colors duration-200">
      {/* Hidden native photo picker */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={handleFilesSelected}
        className="hidden"
      />

      {/* Top Vault Header */}
      <header className="sticky top-0 z-30 border-b border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-[#131a26]/90 backdrop-blur-md">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            {section !== 'menu' && (
              <button
                type="button"
                onClick={() => {
                  if (section === 'preview') handleCancelImport();
                  else setSection('menu');
                }}
                aria-label="Back to vault menu"
                className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800/70 transition-colors shrink-0"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            )}
            <div className="min-w-0">
              <h1 className="text-base sm:text-lg font-semibold tracking-tight truncate">
                Private Photo Vault
              </h1>
              <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2 truncate">
                <span className="font-mono-tabular">
                  {photos.length} {photos.length === 1 ? 'photo' : 'photos'}
                </span>
                <span aria-hidden="true">·</span>
                <span className="font-mono-tabular">{formatBytes(totalSize)}</span>
                <span aria-hidden="true" className="hidden sm:inline">·</span>
                <span className="hidden sm:inline">Local private storage</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={onToggleTheme}
              aria-label={isDarkTheme ? 'Switch to light theme' : 'Switch to dark theme'}
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70 transition-colors"
            >
              {isDarkTheme ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
            <button
              type="button"
              onClick={onLock}
              className="min-h-[44px] inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium bg-slate-900 text-white hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-500 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Lock className="w-4 h-4" />
              Lock
            </button>
          </div>
        </div>

        {/* Navigation Strip */}
        {section !== 'preview' && (
          <div className="max-w-6xl mx-auto px-4 sm:px-6 pb-3 flex items-center gap-1.5 overflow-x-auto">
            <NavTabButton
              active={section === 'menu'}
              label="Menu"
              onClick={() => setSection('menu')}
            />
            <NavTabButton
              active={section === 'gallery'}
              label={`Saved Photos (${photos.length})`}
              onClick={() => setSection('gallery')}
            />
            <NavTabButton
              active={section === 'delete'}
              label="Delete Photos"
              onClick={() => setSection('delete')}
            />
            <NavTabButton
              active={section === 'code'}
              label="Change Secret Code"
              onClick={() => setSection('code')}
            />
            <NavTabButton
              active={section === 'backup'}
              label="Export & Restore"
              onClick={() => setSection('backup')}
            />
            <NavTabButton
              active={section === 'android'}
              label="Android Source"
              onClick={() => setSection('android')}
            />
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-1 w-full max-w-6xl mx-auto p-4 sm:p-6 space-y-5">
        {statusMessage && (
          <div
            role="status"
            className={`flex items-center justify-between gap-3 px-4 py-3 rounded-2xl border text-sm ${
              statusMessage.type === 'success'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900 dark:bg-emerald-950/40 dark:border-emerald-800/60 dark:text-emerald-200'
                : 'bg-red-50 border-red-200 text-red-900 dark:bg-red-950/40 dark:border-red-800/60 dark:text-red-200'
            }`}
          >
            <div className="flex items-center gap-2.5">
              {statusMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
              ) : (
                <AlertTriangle className="w-4 h-4 shrink-0 text-red-600 dark:text-red-400" />
              )}
              <span>{statusMessage.text}</span>
            </div>
            <button
              type="button"
              onClick={() => setStatusMessage(null)}
              aria-label="Dismiss notification"
              className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg hover:bg-black/5 dark:hover:bg-white/10"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* MENU VIEW */}
        {section === 'menu' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <MenuCard
                icon={<ImagePlus className="w-6 h-6" />}
                title="Add Photos"
                description="Select multiple photos from your device gallery, review them, and accept to store privately."
                actionLabel="Open Photo Picker"
                accent
                onClick={triggerPhotoPicker}
              />
              <MenuCard
                icon={<Images className="w-6 h-6" />}
                title="View Saved Photos"
                description={`Browse all ${photos.length} stored photo${photos.length === 1 ? '' : 's'} in a grid and open full-screen zoom viewer.`}
                actionLabel="Open Gallery"
                onClick={() => setSection('gallery')}
              />
              <MenuCard
                icon={<Trash2 className="w-6 h-6" />}
                title="Delete Photos"
                description="Select individual photos to remove permanently or clear the entire private vault."
                actionLabel="Manage Deletions"
                onClick={() => setSection('delete')}
              />
              <MenuCard
                icon={<KeyRound className="w-6 h-6" />}
                title="Change Secret Code"
                description="Update the numeric code entered on the calculator before pressing equals (=)."
                actionLabel="Update Code"
                onClick={() => setSection('code')}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-slate-200 dark:border-slate-800">
              <MenuCard
                icon={<ShieldCheck className="w-5 h-5" />}
                title="Safe Export & Restore"
                description="Create a portable backup archive (optional AES-256 passphrase) or restore photos safely."
                actionLabel="Backup Options"
                onClick={() => setSection('backup')}
              />
              <MenuCard
                icon={<Code2 className="w-5 h-5" />}
                title="Android Studio Kotlin Source"
                description="Inspect and copy the complete Jetpack Compose, Room, and Photo Picker Kotlin codebase."
                actionLabel="View Kotlin Project"
                onClick={() => setSection('android')}
              />
            </div>
          </div>
        )}

        {/* IMPORT PREVIEW SCREEN */}
        {section === 'preview' && (
          <div className="space-y-5 pb-24 sm:pb-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 bg-white dark:bg-[#131a26] border border-slate-200 dark:border-[#232e42] rounded-2xl p-4 sm:p-5">
              <div>
                <h2 className="text-base sm:text-lg font-semibold">
                  Review Selected Photos ({stagedPhotos.length})
                </h2>
                <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
                  {newPhotosInPreviewCount} ready to save privately
                  {stagedPhotos.length - newPhotosInPreviewCount > 0 &&
                    ` · ${stagedPhotos.length - newPhotosInPreviewCount} duplicate skipped automatically`}
                </p>
              </div>
              <div className="hidden sm:flex items-center gap-3 shrink-0">
                <button
                  type="button"
                  onClick={handleCancelImport}
                  disabled={isBusy}
                  className="min-h-[44px] px-5 py-2.5 rounded-xl text-sm font-semibold border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  CANCEL
                </button>
                <button
                  type="button"
                  onClick={handleAcceptImport}
                  disabled={isBusy || newPhotosInPreviewCount === 0}
                  className="min-h-[44px] px-5 py-2.5 rounded-xl text-sm font-semibold bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white transition-colors cursor-pointer"
                >
                  {isBusy ? 'Saving...' : `ACCEPT (${newPhotosInPreviewCount})`}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
              {stagedPhotos.map((item) => (
                <div
                  key={item.tempId}
                  className={`relative bg-white dark:bg-[#131a26] border rounded-2xl overflow-hidden ${
                    item.isDuplicate
                      ? 'border-amber-400 dark:border-amber-600/70 opacity-75'
                      : 'border-slate-200 dark:border-[#232e42]'
                  }`}
                >
                  <div className="aspect-square bg-slate-100 dark:bg-[#0e141f] relative">
                    <img
                      src={item.previewUrl}
                      alt={item.fileName}
                      className="w-full h-full object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => handleRemoveStagedItem(item.tempId)}
                      aria-label={`Remove ${item.fileName}`}
                      className="absolute top-2 right-2 min-h-[34px] min-w-[34px] rounded-full bg-black/65 hover:bg-black/85 text-white flex items-center justify-center"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="p-2.5 space-y-0.5">
                    <div className="text-xs font-medium truncate">{item.fileName}</div>
                    <div className="text-[11px] font-mono-tabular text-slate-500 dark:text-slate-400 truncate">
                      {item.isDuplicate
                        ? 'Duplicate — already in vault'
                        : `${item.width}×${item.height} · ${formatBytes(item.sizeBytes)}`}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Mobile Sticky Accept/Cancel Bar */}
            <div className="sm:hidden fixed bottom-0 left-0 right-0 z-40 p-3 bg-white/95 dark:bg-[#131a26]/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={handleCancelImport}
                disabled={isBusy}
                className="min-h-[48px] rounded-xl text-sm font-semibold border border-slate-300 dark:border-slate-700"
              >
                CANCEL
              </button>
              <button
                type="button"
                onClick={handleAcceptImport}
                disabled={isBusy || newPhotosInPreviewCount === 0}
                className="min-h-[48px] rounded-xl text-sm font-semibold bg-blue-600 text-white disabled:opacity-50"
              >
                {isBusy ? 'Saving...' : `ACCEPT (${newPhotosInPreviewCount})`}
              </button>
            </div>
          </div>
        )}

        {/* SAVED PHOTOS GALLERY */}
        {section === 'gallery' && (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-semibold">Saved Photos</h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Stored permanently in local browser private storage · Never uploaded
                </p>
              </div>
              <button
                type="button"
                onClick={triggerPhotoPicker}
                className="min-h-[44px] inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium bg-blue-600 hover:bg-blue-700 text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <ImagePlus className="w-4 h-4" />
                Add More Photos
              </button>
            </div>

            {isLoading ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
                {Array.from({ length: 5 }).map((_, idx) => (
                  <div
                    key={idx}
                    className="aspect-square rounded-2xl bg-slate-200 dark:bg-slate-800 animate-pulse"
                  />
                ))}
              </div>
            ) : photos.length === 0 ? (
              <div className="bg-white dark:bg-[#131a26] border border-slate-200 dark:border-[#232e42] rounded-3xl p-10 text-center flex flex-col items-center justify-center">
                <Images className="w-10 h-10 text-slate-400 dark:text-slate-600 mb-3" />
                <h3 className="text-base font-semibold">No photos saved yet</h3>
                <p className="text-sm text-slate-500 dark:text-slate-400 max-w-md mt-1 mb-5">
                  Import photos from your device gallery to keep them hidden inside the Smart Calculator private vault.
                </p>
                <button
                  type="button"
                  onClick={triggerPhotoPicker}
                  className="min-h-[44px] inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold bg-blue-600 hover:bg-blue-700 text-white transition-colors cursor-pointer"
                >
                  <ImagePlus className="w-4 h-4" />
                  Add Photos
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
                {photos.map((photo, idx) => (
                  <button
                    key={photo.id}
                    type="button"
                    onClick={() => setViewerIndex(idx)}
                    className="group text-left bg-white dark:bg-[#131a26] border border-slate-200 dark:border-[#232e42] rounded-2xl overflow-hidden hover:border-blue-500/60 transition-colors focus-visible:outline-2 focus-visible:outline-blue-500 cursor-pointer"
                  >
                    <div className="aspect-square bg-slate-100 dark:bg-[#0e141f] overflow-hidden">
                      <img
                        src={photo.url}
                        alt={photo.fileName}
                        loading="lazy"
                        className="w-full h-full object-cover transition-transform duration-200 group-hover:scale-[1.03]"
                      />
                    </div>
                    <div className="p-2.5">
                      <div className="text-xs font-medium truncate">{photo.fileName}</div>
                      <div className="text-[11px] font-mono-tabular text-slate-500 dark:text-slate-400 mt-0.5 truncate">
                        {photo.width > 0 ? `${photo.width}×${photo.height} · ` : ''}
                        {formatBytes(photo.sizeBytes)}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* DELETE PHOTOS */}
        {section === 'delete' && (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 bg-white dark:bg-[#131a26] border border-slate-200 dark:border-[#232e42] rounded-2xl p-4">
              <div>
                <h2 className="text-base sm:text-lg font-semibold">Delete Photos</h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {selectedIds.size} selected of {photos.length} saved
                </p>
              </div>

              {photos.length > 0 && (
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      if (selectedIds.size === photos.length) setSelectedIds(new Set());
                      else setSelectedIds(new Set(photos.map((p) => p.id)));
                    }}
                    className="min-h-[40px] px-3 py-1.5 rounded-xl text-xs font-medium border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap"
                  >
                    {selectedIds.size === photos.length ? 'Deselect All' : 'Select All'}
                  </button>
                  <button
                    type="button"
                    disabled={selectedIds.size === 0 || isBusy}
                    onClick={handleDeleteSelected}
                    className="min-h-[40px] px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-red-600 hover:bg-red-700 disabled:opacity-40 text-white whitespace-nowrap cursor-pointer"
                  >
                    Delete Selected ({selectedIds.size})
                  </button>
                  <button
                    type="button"
                    disabled={isBusy}
                    onClick={() => setShowDeleteAllConfirm(true)}
                    className="min-h-[40px] px-3.5 py-1.5 rounded-xl text-xs font-semibold border border-red-300 dark:border-red-800/70 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 whitespace-nowrap cursor-pointer"
                  >
                    Delete All
                  </button>
                </div>
              )}
            </div>

            {photos.length === 0 ? (
              <div className="bg-white dark:bg-[#131a26] border border-slate-200 dark:border-[#232e42] rounded-3xl p-10 text-center">
                <p className="text-sm text-slate-500 dark:text-slate-400">
                  No photos to delete. Your private vault is empty.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
                {photos.map((photo) => {
                  const selected = selectedIds.has(photo.id);
                  return (
                    <button
                      key={photo.id}
                      type="button"
                      onClick={() => toggleSelectDelete(photo.id)}
                      aria-pressed={selected}
                      className={`relative text-left bg-white dark:bg-[#131a26] rounded-2xl overflow-hidden border-2 transition-colors cursor-pointer ${
                        selected
                          ? 'border-red-500'
                          : 'border-slate-200 dark:border-[#232e42] hover:border-slate-400'
                      }`}
                    >
                      <div className="aspect-square bg-slate-100 dark:bg-[#0e141f] relative">
                        <img
                          src={photo.url}
                          alt={photo.fileName}
                          className={`w-full h-full object-cover transition-opacity ${
                            selected ? 'opacity-80' : ''
                          }`}
                        />
                        <div
                          className={`absolute top-2.5 right-2.5 w-6 h-6 rounded-full flex items-center justify-center border ${
                            selected
                              ? 'bg-red-600 border-red-600 text-white'
                              : 'bg-black/40 border-white/80 text-transparent'
                          }`}
                        >
                          <Check className="w-3.5 h-3.5" />
                        </div>
                      </div>
                      <div className="p-2.5">
                        <div className="text-xs font-medium truncate">{photo.fileName}</div>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* CHANGE SECRET CODE */}
        {section === 'code' && (
          <div className="max-w-lg mx-auto bg-white dark:bg-[#131a26] border border-slate-200 dark:border-[#232e42] rounded-3xl p-6 space-y-5">
            <div>
              <h2 className="text-lg font-semibold">Change Secret Code</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Enter your current code and choose a new 4–12 digit numeric unlock code. Default code is 859115.
              </p>
            </div>

            <form onSubmit={handleChangeCodeSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Current Secret Code
                </label>
                <input
                  type="password"
                  inputMode="numeric"
                  value={currentCodeInput}
                  onChange={(e) => setCurrentCodeInput(e.target.value.replace(/\D/g, ''))}
                  placeholder="Enter current digits"
                  className="w-full min-h-[44px] px-3.5 rounded-xl bg-slate-50 dark:bg-[#0e141f] border border-slate-200 dark:border-slate-700 font-mono-tabular text-sm focus:outline-2 focus:outline-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  New Secret Code (4–12 digits)
                </label>
                <input
                  type="password"
                  inputMode="numeric"
                  maxLength={12}
                  value={newCodeInput}
                  onChange={(e) => setNewCodeInput(e.target.value.replace(/\D/g, ''))}
                  placeholder="Enter new digits"
                  className="w-full min-h-[44px] px-3.5 rounded-xl bg-slate-50 dark:bg-[#0e141f] border border-slate-200 dark:border-slate-700 font-mono-tabular text-sm focus:outline-2 focus:outline-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Confirm New Secret Code
                </label>
                <input
                  type="password"
                  inputMode="numeric"
                  maxLength={12}
                  value={confirmCodeInput}
                  onChange={(e) => setConfirmCodeInput(e.target.value.replace(/\D/g, ''))}
                  placeholder="Re-enter new digits"
                  className="w-full min-h-[44px] px-3.5 rounded-xl bg-slate-50 dark:bg-[#0e141f] border border-slate-200 dark:border-slate-700 font-mono-tabular text-sm focus:outline-2 focus:outline-blue-500"
                  required
                />
              </div>

              {codeError && (
                <p className="text-xs font-medium text-red-600 dark:text-red-400">
                  {codeError}
                </p>
              )}

              <button
                type="submit"
                className="w-full min-h-[46px] rounded-xl text-sm font-semibold bg-blue-600 hover:bg-blue-700 text-white transition-colors cursor-pointer"
              >
                Update Secret Code
              </button>
            </form>
          </div>
        )}

        {/* EXPORT & RESTORE */}
        {section === 'backup' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Export */}
            <div className="bg-white dark:bg-[#131a26] border border-slate-200 dark:border-[#232e42] rounded-3xl p-6 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-500/15 text-blue-600 dark:text-blue-400 flex items-center justify-center">
                  <Download className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-semibold">Export Vault Backup</h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Save a portable recovery file ({photos.length} photos)
                  </p>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Optional Encryption Passphrase (AES-256-GCM)
                </label>
                <input
                  type="password"
                  value={exportPassphrase}
                  onChange={(e) => setExportPassphrase(e.target.value)}
                  placeholder="Leave blank for unencrypted JSON backup"
                  className="w-full min-h-[44px] px-3.5 rounded-xl bg-slate-50 dark:bg-[#0e141f] border border-slate-200 dark:border-slate-700 text-sm focus:outline-2 focus:outline-blue-500"
                />
              </div>

              <button
                type="button"
                onClick={handleExportBackup}
                disabled={isBusy || photos.length === 0}
                className="w-full min-h-[46px] inline-flex items-center justify-center gap-2 rounded-xl text-sm font-semibold bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white transition-colors cursor-pointer"
              >
                <Download className="w-4 h-4" />
                Export Recovery File (.scvault.json)
              </button>
            </div>

            {/* Restore */}
            <div className="bg-white dark:bg-[#131a26] border border-slate-200 dark:border-[#232e42] rounded-3xl p-6 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 flex items-center justify-center">
                  <Upload className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-semibold">Restore from Backup</h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Recover photos without overwriting existing items
                  </p>
                </div>
              </div>

              <input
                ref={restoreInputRef}
                type="file"
                accept=".json,.scvault.json,application/json"
                onChange={handleSelectRestoreFile}
                className="hidden"
              />

              <button
                type="button"
                onClick={() => {
                  if (restoreInputRef.current) {
                    restoreInputRef.current.value = '';
                    restoreInputRef.current.click();
                  }
                }}
                className="w-full min-h-[46px] rounded-xl text-sm font-medium border border-dashed border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-[#1b2434] transition-colors px-4 truncate cursor-pointer"
              >
                {restoreFile ? restoreFile.name : 'Choose .scvault.json Backup File'}
              </button>

              {restoreFile && restoreNeedsPassphrase && (
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                    Backup Passphrase Required
                  </label>
                  <input
                    type="password"
                    value={restorePassphrase}
                    onChange={(e) => setRestorePassphrase(e.target.value)}
                    placeholder="Enter encryption passphrase"
                    className="w-full min-h-[44px] px-3.5 rounded-xl bg-slate-50 dark:bg-[#0e141f] border border-slate-200 dark:border-slate-700 text-sm focus:outline-2 focus:outline-blue-500"
                  />
                </div>
              )}

              {restoreFile && (
                <button
                  type="button"
                  onClick={handleExecuteRestore}
                  disabled={isBusy}
                  className="w-full min-h-[46px] rounded-xl text-sm font-semibold bg-slate-900 hover:bg-slate-800 dark:bg-blue-600 dark:hover:bg-blue-500 text-white transition-colors cursor-pointer"
                >
                  {isBusy ? 'Restoring...' : 'Restore Photos to Vault'}
                </button>
              )}
            </div>
          </div>
        )}

        {/* ANDROID STUDIO SOURCE */}
        {section === 'android' && <AndroidSourceViewer />}
      </main>

      {/* Full-Screen Zoom Viewer */}
      {viewerIndex !== null && photos.length > 0 && (
        <FullScreenPhotoModal
          photos={photos}
          initialIndex={viewerIndex}
          onClose={() => setViewerIndex(null)}
        />
      )}

      {/* Delete All Confirmation Dialog */}
      {showDeleteAllConfirm && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="delete-all-title"
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
        >
          <div className="w-full max-w-md bg-white dark:bg-[#131a26] border border-slate-200 dark:border-[#232e42] rounded-3xl p-6 space-y-4 shadow-xl">
            <h3 id="delete-all-title" className="text-lg font-semibold">
              Delete all {photos.length} photos?
            </h3>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              All photos stored inside your private vault will be permanently removed from local storage. This action cannot be undone.
            </p>
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowDeleteAllConfirm(false)}
                className="min-h-[44px] px-4 py-2 rounded-xl text-sm font-medium border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteAllConfirm}
                className="min-h-[44px] px-4 py-2 rounded-xl text-sm font-semibold bg-red-600 hover:bg-red-700 text-white cursor-pointer"
              >
                Delete All Photos
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const NavTabButton: React.FC<{
  active: boolean;
  label: string;
  onClick: () => void;
}> = ({ active, label, onClick }) => (
  <button
    type="button"
    onClick={onClick}
    className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-medium whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
      active
        ? 'bg-blue-600 text-white dark:bg-blue-500'
        : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70'
    }`}
  >
    {label}
  </button>
);

const MenuCard: React.FC<{
  icon: React.ReactNode;
  title: string;
  description: string;
  actionLabel: string;
  accent?: boolean;
  onClick: () => void;
}> = ({ icon, title, description, actionLabel, accent = false, onClick }) => (
  <button
    type="button"
    onClick={onClick}
    className="text-left bg-white dark:bg-[#131a26] border border-slate-200 dark:border-[#232e42] hover:border-blue-500/60 dark:hover:border-blue-500/60 rounded-3xl p-5 sm:p-6 flex flex-col justify-between gap-4 transition-colors focus-visible:outline-2 focus-visible:outline-blue-500 cursor-pointer group"
  >
    <div className="flex items-start gap-4">
      <div
        className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${
          accent
            ? 'bg-blue-600 text-white dark:bg-blue-500'
            : 'bg-slate-100 text-slate-700 dark:bg-[#1b2434] dark:text-slate-200'
        }`}
      >
        {icon}
      </div>
      <div className="space-y-1">
        <h2 className="text-base font-semibold text-slate-900 dark:text-slate-50">
          {title}
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
          {description}
        </p>
      </div>
    </div>
    <div className="text-xs font-semibold text-blue-600 dark:text-blue-400 group-hover:underline">
      {actionLabel} →
    </div>
  </button>
);
