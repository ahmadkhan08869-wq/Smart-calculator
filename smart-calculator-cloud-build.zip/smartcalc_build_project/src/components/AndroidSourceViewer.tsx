import React, { useState } from 'react';
import { Check, Copy, Download, FileCode2 } from 'lucide-react';
import { ANDROID_SOURCE_FILES, AndroidSourceFile } from '../data/androidSourceFiles';

export const AndroidSourceViewer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<AndroidSourceFile>(ANDROID_SOURCE_FILES[0]);
  const [copiedPath, setCopiedPath] = useState<string | null>(null);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(selectedFile.content);
      setCopiedPath(selectedFile.path);
      setTimeout(() => setCopiedPath(null), 1800);
    } catch {
      // Fallback ignored
    }
  };

  const handleDownloadFile = () => {
    const blob = new Blob([selectedFile.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = selectedFile.label;
    a.click();
    URL.revokeObjectURL(url);
  };

  const categories: AndroidSourceFile['category'][] = [
    'App & UI',
    'Storage & Room',
    'Gradle & Manifest',
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="text-lg font-semibold">Android Studio Source (Kotlin + Jetpack Compose)</h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Complete project source located in /android — Room DB · Photo Picker · EncryptedSharedPreferences · FLAG_SECURE
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* File Tree */}
        <div className="lg:col-span-4 bg-white dark:bg-[#131a26] border border-slate-200 dark:border-[#232e42] rounded-2xl p-3 max-h-[520px] overflow-y-auto space-y-4">
          {categories.map((category) => (
            <div key={category}>
              <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 px-2 pb-1.5">
                {category}
              </div>
              <div className="space-y-1">
                {ANDROID_SOURCE_FILES.filter((f) => f.category === category).map((file) => {
                  const isActive = file.path === selectedFile.path;
                  return (
                    <button
                      key={file.path}
                      type="button"
                      onClick={() => setSelectedFile(file)}
                      className={`w-full flex items-center gap-2 text-left px-2.5 py-2 rounded-xl text-xs font-medium transition-colors min-h-[40px] ${
                        isActive
                          ? 'bg-blue-600 text-white dark:bg-blue-500'
                          : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-[#1b2434]'
                      }`}
                    >
                      <FileCode2 className="w-4 h-4 shrink-0" />
                      <span className="truncate">{file.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Code Viewer */}
        <div className="lg:col-span-8 bg-white dark:bg-[#131a26] border border-slate-200 dark:border-[#232e42] rounded-2xl flex flex-col overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 bg-slate-50 dark:bg-[#0e141f]">
            <span className="font-mono-tabular text-xs text-slate-600 dark:text-slate-300 truncate">
              android/{selectedFile.path}
            </span>
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={handleCopy}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-white dark:bg-[#1b2434] border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-[#243044] transition-colors min-h-[36px] whitespace-nowrap"
              >
                {copiedPath === selectedFile.path ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                    Copied
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    Copy
                  </>
                )}
              </button>
              <button
                type="button"
                onClick={handleDownloadFile}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-blue-600 hover:bg-blue-700 text-white transition-colors min-h-[36px] whitespace-nowrap"
              >
                <Download className="w-3.5 h-3.5" />
                Download
              </button>
            </div>
          </div>
          <pre className="p-4 text-xs font-mono-tabular leading-relaxed overflow-auto max-h-[468px] text-slate-800 dark:text-slate-200">
            <code>{selectedFile.content}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};
