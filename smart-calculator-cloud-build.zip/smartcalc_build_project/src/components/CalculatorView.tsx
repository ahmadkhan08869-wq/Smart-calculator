import React, { useEffect, useState } from 'react';
import { Delete, History, Moon, Sun, Trash2, X } from 'lucide-react';
import {
  CalcOperator,
  CalculatorState,
  HistoryEntry,
} from '../utils/calculatorEngine';

interface CalculatorViewProps {
  state: CalculatorState;
  history: HistoryEntry[];
  isDarkTheme: boolean;
  onToggleTheme: () => void;
  onDigit: (digit: string) => void;
  onDecimal: () => void;
  onToggleSign: () => void;
  onPercent: () => void;
  onOperator: (op: CalcOperator) => void;
  onClear: () => void;
  onBackspace: () => void;
  onEquals: () => void;
  onReuseResult: (value: string) => void;
  onClearHistory: () => void;
}

export const CalculatorView: React.FC<CalculatorViewProps> = ({
  state,
  history,
  isDarkTheme,
  onToggleTheme,
  onDigit,
  onDecimal,
  onToggleSign,
  onPercent,
  onOperator,
  onClear,
  onBackspace,
  onEquals,
  onReuseResult,
  onClearHistory,
}) => {
  const [mobileHistoryOpen, setMobileHistoryOpen] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const key = e.key;

      if (key >= '0' && key <= '9') {
        e.preventDefault();
        onDigit(key);
      } else if (key === '.') {
        e.preventDefault();
        onDecimal();
      } else if (key === '+') {
        e.preventDefault();
        onOperator('+');
      } else if (key === '-') {
        e.preventDefault();
        onOperator('−');
      } else if (key === '*') {
        e.preventDefault();
        onOperator('×');
      } else if (key === '/') {
        e.preventDefault();
        onOperator('÷');
      } else if (key === '%') {
        e.preventDefault();
        onPercent();
      } else if (key === 'Enter' || key === '=') {
        e.preventDefault();
        onEquals();
      } else if (key === 'Backspace') {
        e.preventDefault();
        onBackspace();
      } else if (key === 'Escape' || key === 'Delete') {
        e.preventDefault();
        onClear();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onDigit, onDecimal, onOperator, onPercent, onEquals, onBackspace, onClear]);

  const displayLength = state.currentDisplay.length;
  const displaySizeClass =
    displayLength > 13
      ? 'text-3xl sm:text-4xl'
      : displayLength > 9
        ? 'text-4xl sm:text-5xl'
        : 'text-5xl sm:text-6xl';

  return (
    <div className="min-h-dvh flex flex-col bg-[#f4f6f8] dark:bg-[#0b0f17] text-slate-900 dark:text-slate-50 transition-colors duration-200">
      {/* Top Bar */}
      <header className="w-full border-b border-slate-200/80 dark:border-slate-800/80 bg-white/80 dark:bg-[#131a26]/80 backdrop-blur-md">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4">
          <h1 className="text-base sm:text-lg font-semibold tracking-tight whitespace-nowrap shrink-0">
            Smart Calculator
          </h1>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => setMobileHistoryOpen((prev) => !prev)}
              aria-label="Calculation history"
              className="lg:hidden min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70 transition-colors focus-visible:outline-2 focus-visible:outline-blue-500"
            >
              <History className="w-5 h-5" />
            </button>
            <button
              type="button"
              onClick={onToggleTheme}
              aria-label={isDarkTheme ? 'Switch to light theme' : 'Switch to dark theme'}
              className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70 transition-colors focus-visible:outline-2 focus-visible:outline-blue-500"
            >
              {isDarkTheme ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Main Workspace */}
      <main className="flex-1 w-full max-w-5xl mx-auto p-3 sm:p-6 flex flex-col lg:grid lg:grid-cols-12 lg:gap-6 lg:items-stretch">
        {/* Calculator Panel */}
        <section
          aria-label="Calculator"
          className="flex-1 lg:col-span-7 flex flex-col justify-between bg-white dark:bg-[#131a26] border border-slate-200 dark:border-[#232e42] rounded-3xl p-4 sm:p-6 shadow-sm"
        >
          {/* Numeric Display */}
          <div className="flex flex-col justify-end items-end min-h-[132px] sm:min-h-[164px] px-2 py-4 mb-4 rounded-2xl bg-slate-50 dark:bg-[#0e141f] border border-slate-200/70 dark:border-slate-800/80 overflow-hidden">
            <div className="font-mono-tabular text-sm sm:text-base text-slate-500 dark:text-slate-400 min-h-[24px] w-full text-right truncate">
              {state.expressionDisplay}
            </div>
            <div
              data-testid="calculator-display"
              className={`font-mono-tabular font-bold tracking-tight mt-2 w-full text-right truncate ${displaySizeClass} ${
                state.isError
                  ? 'text-red-600 dark:text-red-400'
                  : 'text-slate-900 dark:text-slate-50'
              }`}
            >
              {state.currentDisplay}
            </div>
          </div>

          {/* 4x5 Uniform Keypad */}
          <div className="grid grid-cols-4 gap-2.5 sm:gap-3">
            <CalcButton label="C" variant="action" onClick={onClear} ariaLabel="Clear all" />
            <CalcButton
              label={<Delete className="w-5 h-5 sm:w-6 sm:h-6" />}
              variant="action"
              onClick={onBackspace}
              ariaLabel="Backspace"
            />
            <CalcButton label="%" variant="action" onClick={onPercent} ariaLabel="Percent" />
            <CalcButton
              label="÷"
              variant="operator"
              active={state.pendingOperator === '÷' && state.shouldResetInput}
              onClick={() => onOperator('÷')}
              ariaLabel="Divide"
            />

            <CalcButton label="7" onClick={() => onDigit('7')} />
            <CalcButton label="8" onClick={() => onDigit('8')} />
            <CalcButton label="9" onClick={() => onDigit('9')} />
            <CalcButton
              label="×"
              variant="operator"
              active={state.pendingOperator === '×' && state.shouldResetInput}
              onClick={() => onOperator('×')}
              ariaLabel="Multiply"
            />

            <CalcButton label="4" onClick={() => onDigit('4')} />
            <CalcButton label="5" onClick={() => onDigit('5')} />
            <CalcButton label="6" onClick={() => onDigit('6')} />
            <CalcButton
              label="−"
              variant="operator"
              active={state.pendingOperator === '−' && state.shouldResetInput}
              onClick={() => onOperator('−')}
              ariaLabel="Subtract"
            />

            <CalcButton label="1" onClick={() => onDigit('1')} />
            <CalcButton label="2" onClick={() => onDigit('2')} />
            <CalcButton label="3" onClick={() => onDigit('3')} />
            <CalcButton
              label="+"
              variant="operator"
              active={state.pendingOperator === '+' && state.shouldResetInput}
              onClick={() => onOperator('+')}
              ariaLabel="Add"
            />

            <CalcButton label="±" onClick={onToggleSign} ariaLabel="Toggle sign" />
            <CalcButton label="0" onClick={() => onDigit('0')} />
            <CalcButton label="." onClick={onDecimal} ariaLabel="Decimal point" />
            <CalcButton label="=" variant="equals" onClick={onEquals} ariaLabel="Equals" />
          </div>
        </section>

        {/* Desktop Calculation Tape */}
        <aside
          aria-label="Calculation history"
          className="hidden lg:flex lg:col-span-5 flex-col bg-white dark:bg-[#131a26] border border-slate-200 dark:border-[#232e42] rounded-3xl p-6 shadow-sm"
        >
          <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
            <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              History Tape
            </h2>
            {history.length > 0 && (
              <button
                type="button"
                onClick={onClearHistory}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-500 hover:text-red-600 dark:text-slate-400 dark:hover:text-red-400 min-h-[36px] px-2.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800/60 transition-colors whitespace-nowrap shrink-0"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Clear
              </button>
            )}
          </div>

          <div className="flex-1 overflow-y-auto mt-4 space-y-2 max-h-[440px] pr-1">
            {history.length === 0 ? (
              <div className="h-full min-h-[260px] flex flex-col items-center justify-center text-center px-4">
                <History className="w-8 h-8 text-slate-300 dark:text-slate-700 mb-3" />
                <p className="text-sm font-medium text-slate-600 dark:text-slate-400">
                  No calculations yet
                </p>
                <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">
                  Completed expressions appear here for quick reuse.
                </p>
              </div>
            ) : (
              history.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onReuseResult(item.result)}
                  className="w-full text-right p-3 rounded-xl hover:bg-slate-50 dark:hover:bg-[#1b2434] border border-transparent hover:border-slate-200 dark:hover:border-slate-700/70 transition-colors group"
                >
                  <div className="font-mono-tabular text-xs text-slate-500 dark:text-slate-400 truncate">
                    {item.expression} =
                  </div>
                  <div className="font-mono-tabular text-lg font-semibold text-slate-900 dark:text-slate-100 mt-0.5 truncate group-hover:text-blue-600 dark:group-hover:text-blue-400">
                    {item.result}
                  </div>
                </button>
              ))
            )}
          </div>
        </aside>
      </main>

      {/* Mobile History Sheet */}
      {mobileHistoryOpen && (
        <div
          className="lg:hidden fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-end"
          onClick={() => setMobileHistoryOpen(false)}
        >
          <div
            className="w-full max-h-[70dvh] bg-white dark:bg-[#131a26] rounded-t-3xl border-t border-slate-200 dark:border-slate-800 p-4 flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-10 h-1.5 rounded-full bg-slate-300 dark:bg-slate-700 mx-auto mb-3" />
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h2 className="text-sm font-semibold">History Tape</h2>
              <div className="flex items-center gap-2">
                {history.length > 0 && (
                  <button
                    type="button"
                    onClick={onClearHistory}
                    className="text-xs font-medium text-red-600 dark:text-red-400 px-2.5 py-1.5 rounded-lg"
                  >
                    Clear
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setMobileHistoryOpen(false)}
                  aria-label="Close history"
                  className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-lg text-slate-500"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto py-3 space-y-2">
              {history.length === 0 ? (
                <p className="text-center text-sm text-slate-500 py-10">No calculations yet</p>
              ) : (
                history.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      onReuseResult(item.result);
                      setMobileHistoryOpen(false);
                    }}
                    className="w-full text-right p-3 rounded-xl bg-slate-50 dark:bg-[#1b2434]"
                  >
                    <div className="font-mono-tabular text-xs text-slate-500 dark:text-slate-400">
                      {item.expression} =
                    </div>
                    <div className="font-mono-tabular text-lg font-semibold mt-0.5">
                      {item.result}
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

interface CalcButtonProps {
  label: React.ReactNode;
  variant?: 'digit' | 'action' | 'operator' | 'equals';
  active?: boolean;
  onClick: () => void;
  ariaLabel?: string;
}

const CalcButton: React.FC<CalcButtonProps> = ({
  label,
  variant = 'digit',
  active = false,
  onClick,
  ariaLabel,
}) => {
  let styleClass =
    'bg-slate-100 hover:bg-slate-200/80 active:bg-slate-200 text-slate-900 dark:bg-[#1b2434] dark:hover:bg-[#232f44] dark:active:bg-[#29364e] dark:text-slate-50';

  if (variant === 'action') {
    styleClass =
      'bg-slate-200/80 hover:bg-slate-300/80 text-slate-800 dark:bg-[#243044] dark:hover:bg-[#2d3b53] dark:text-slate-100';
  } else if (variant === 'operator') {
    styleClass = active
      ? 'bg-blue-600 text-white dark:bg-blue-500 dark:text-white'
      : 'bg-blue-50 hover:bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:hover:bg-blue-500/25 dark:text-blue-400';
  } else if (variant === 'equals') {
    styleClass =
      'bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white dark:bg-blue-500 dark:hover:bg-blue-600 dark:text-white shadow-sm';
  }

  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={ariaLabel}
      className={`font-mono-tabular min-h-[60px] sm:min-h-[68px] rounded-2xl text-xl sm:text-2xl font-semibold flex items-center justify-center select-none transition-all duration-150 active:scale-[0.96] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-500 cursor-pointer ${styleClass}`}
    >
      {label}
    </button>
  );
};
