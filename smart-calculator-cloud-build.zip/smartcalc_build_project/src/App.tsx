import { useEffect, useState } from 'react';
import { CalculatorView } from './components/CalculatorView';
import { VaultView } from './components/VaultView';
import {
  appendDecimal,
  appendDigit,
  applyPercent,
  backspace,
  CalcOperator,
  CalculatorState,
  chooseOperator,
  clearAll,
  evaluateEquals,
  HistoryEntry,
  INITIAL_CALCULATOR_STATE,
  toggleSign,
} from './utils/calculatorEngine';
import {
  getSavedTheme,
  getSecretCode,
  saveTheme,
} from './utils/vaultStorage';

export default function App() {
  const [calcState, setCalcState] = useState<CalculatorState>(INITIAL_CALCULATOR_STATE);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [isVaultUnlocked, setIsVaultUnlocked] = useState(false);
  const [theme, setTheme] = useState<'dark' | 'light'>(() => getSavedTheme());

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    saveTheme(theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  const handleEquals = () => {
    const secretCode = getSecretCode();
    const outcome = evaluateEquals(calcState, secretCode);
    if (outcome.unlockVault) {
      setCalcState(clearAll());
      setIsVaultUnlocked(true);
      return;
    }
    setCalcState(outcome.state);
    if (outcome.historyItem) {
      setHistory((prev) => [outcome.historyItem!, ...prev].slice(0, 50));
    }
  };

  const handleReuseResult = (value: string) => {
    setCalcState((prev) => ({
      ...prev,
      currentDisplay: value,
      shouldResetInput: false,
      isError: false,
    }));
  };

  if (isVaultUnlocked) {
    return (
      <VaultView
        isDarkTheme={theme === 'dark'}
        onToggleTheme={toggleTheme}
        onLock={() => {
          setCalcState(clearAll());
          setIsVaultUnlocked(false);
        }}
      />
    );
  }

  return (
    <CalculatorView
      state={calcState}
      history={history}
      isDarkTheme={theme === 'dark'}
      onToggleTheme={toggleTheme}
      onDigit={(d) => setCalcState((prev) => appendDigit(prev, d))}
      onDecimal={() => setCalcState((prev) => appendDecimal(prev))}
      onToggleSign={() => setCalcState((prev) => toggleSign(prev))}
      onPercent={() => setCalcState((prev) => applyPercent(prev))}
      onOperator={(op: CalcOperator) => setCalcState((prev) => chooseOperator(prev, op))}
      onClear={() => setCalcState(clearAll())}
      onBackspace={() => setCalcState((prev) => backspace(prev))}
      onEquals={handleEquals}
      onReuseResult={handleReuseResult}
      onClearHistory={() => setHistory([])}
    />
  );
}
