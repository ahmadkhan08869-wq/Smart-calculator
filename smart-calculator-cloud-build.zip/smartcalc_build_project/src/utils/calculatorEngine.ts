export type CalcOperator = '+' | '−' | '×' | '÷';

export interface CalculatorState {
  currentDisplay: string;
  expressionDisplay: string;
  previousOperand: string | null;
  pendingOperator: CalcOperator | null;
  shouldResetInput: boolean;
  isError: boolean;
}

export interface HistoryEntry {
  id: string;
  expression: string;
  result: string;
  timestamp: number;
}

export const INITIAL_CALCULATOR_STATE: CalculatorState = {
  currentDisplay: '0',
  expressionDisplay: '',
  previousOperand: null,
  pendingOperator: null,
  shouldResetInput: false,
  isError: false,
};

const MAX_DIGITS = 15;

export function appendDigit(state: CalculatorState, digit: string): CalculatorState {
  if (state.isError || state.shouldResetInput) {
    return {
      ...state,
      currentDisplay: digit,
      shouldResetInput: false,
      isError: false,
    };
  }
  const next = state.currentDisplay === '0' ? digit : state.currentDisplay + digit;
  const digitCount = next.replace('-', '').replace('.', '').length;
  if (digitCount > MAX_DIGITS) {
    return state;
  }
  return {
    ...state,
    currentDisplay: next,
  };
}

export function appendDecimal(state: CalculatorState): CalculatorState {
  if (state.isError || state.shouldResetInput) {
    return {
      ...state,
      currentDisplay: '0.',
      shouldResetInput: false,
      isError: false,
    };
  }
  if (state.currentDisplay.includes('.')) {
    return state;
  }
  return {
    ...state,
    currentDisplay: `${state.currentDisplay}.`,
  };
}

export function toggleSign(state: CalculatorState): CalculatorState {
  if (state.isError || state.currentDisplay === '0') {
    return state;
  }
  const next = state.currentDisplay.startsWith('-')
    ? state.currentDisplay.slice(1)
    : `-${state.currentDisplay}`;
  return {
    ...state,
    currentDisplay: next,
  };
}

export function applyPercent(state: CalculatorState): CalculatorState {
  if (state.isError) return state;
  const currentVal = Number.parseFloat(state.currentDisplay);
  if (Number.isNaN(currentVal)) return state;

  let result: number;
  if (
    state.previousOperand !== null &&
    (state.pendingOperator === '+' || state.pendingOperator === '−')
  ) {
    const base = Number.parseFloat(state.previousOperand);
    result = (base * currentVal) / 100;
  } else {
    result = currentVal / 100;
  }

  return {
    ...state,
    currentDisplay: formatNumericResult(result),
    shouldResetInput: false,
  };
}

export function chooseOperator(state: CalculatorState, op: CalcOperator): CalculatorState {
  if (state.isError) return state;

  let working = state;
  if (state.pendingOperator !== null && !state.shouldResetInput && state.previousOperand !== null) {
    const evaluated = evaluateBinary(state);
    if (evaluated.state.isError) {
      return evaluated.state;
    }
    working = evaluated.state;
  }

  return {
    ...working,
    previousOperand: working.currentDisplay,
    pendingOperator: op,
    expressionDisplay: `${working.currentDisplay} ${op}`,
    shouldResetInput: true,
  };
}

export function clearAll(): CalculatorState {
  return { ...INITIAL_CALCULATOR_STATE };
}

export function backspace(state: CalculatorState): CalculatorState {
  if (state.isError || state.shouldResetInput) {
    return {
      ...state,
      currentDisplay: '0',
      shouldResetInput: false,
      isError: false,
    };
  }
  const trimmed = state.currentDisplay.slice(0, -1);
  return {
    ...state,
    currentDisplay: trimmed === '' || trimmed === '-' ? '0' : trimmed,
  };
}

export function evaluateEquals(
  state: CalculatorState,
  secretCode: string
): { unlockVault: boolean; state: CalculatorState; historyItem?: HistoryEntry } {
  // Secret code check: exact match entered without pending operator
  if (state.pendingOperator === null && state.currentDisplay === secretCode) {
    return {
      unlockVault: true,
      state: clearAll(),
    };
  }

  if (state.isError || state.pendingOperator === null || state.previousOperand === null) {
    return {
      unlockVault: false,
      state,
    };
  }

  const evaluated = evaluateBinary(state);
  return {
    unlockVault: false,
    state: evaluated.state,
    historyItem: evaluated.historyItem,
  };
}

function evaluateBinary(state: CalculatorState): {
  state: CalculatorState;
  historyItem?: HistoryEntry;
} {
  const a = Number.parseFloat(state.previousOperand ?? '');
  const b = Number.parseFloat(state.currentDisplay);
  const op = state.pendingOperator;

  if (Number.isNaN(a) || Number.isNaN(b) || op === null) {
    return { state };
  }

  let rawResult: number;
  switch (op) {
    case '+':
      rawResult = a + b;
      break;
    case '−':
      rawResult = a - b;
      break;
    case '×':
      rawResult = a * b;
      break;
    case '÷':
      if (b === 0) {
        return {
          state: {
            currentDisplay: 'Error',
            expressionDisplay: `${state.previousOperand} ÷ 0`,
            previousOperand: null,
            pendingOperator: null,
            shouldResetInput: true,
            isError: true,
          },
        };
      }
      rawResult = a / b;
      break;
  }

  if (!Number.isFinite(rawResult)) {
    return {
      state: {
        currentDisplay: 'Error',
        expressionDisplay: '',
        previousOperand: null,
        pendingOperator: null,
        shouldResetInput: true,
        isError: true,
      },
    };
  }

  const formatted = formatNumericResult(rawResult);
  const expression = `${state.previousOperand} ${op} ${state.currentDisplay}`;

  return {
    state: {
      currentDisplay: formatted,
      expressionDisplay: `${expression} =`,
      previousOperand: null,
      pendingOperator: null,
      shouldResetInput: true,
      isError: false,
    },
    historyItem: {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      expression,
      result: formatted,
      timestamp: Date.now(),
    },
  };
}

export function formatNumericResult(value: number): string {
  if (Object.is(value, -0) || value === 0) return '0';
  const rounded = Number(value.toPrecision(12));
  const str = String(rounded);
  if (str.length <= 16) return str;
  return rounded.toExponential(6).replace(/\.?0+e/, 'e');
}
