const DB_NAME = 'SmartCalculatorVaultDB';
const DB_VERSION = 1;
const STORE_PHOTOS = 'photos';
const SECRET_CODE_KEY = 'smart_calc_secret_code_v1';
const THEME_KEY = 'smart_calc_theme_v1';

export const DEFAULT_SECRET_CODE = '859115';

export interface StoredVaultPhoto {
  id: string;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
  width: number;
  height: number;
  sha256Hash: string;
  createdAt: number;
  data: ArrayBuffer;
}

export interface StagedPhotoPreview {
  tempId: string;
  file: File;
  previewUrl: string;
  fileName: string;
  mimeType: string;
  sizeBytes: number;
  width: number;
  height: number;
  sha256Hash: string;
  isDuplicate: boolean;
  buffer: ArrayBuffer;
}

export interface ImportSummary {
  savedCount: number;
  duplicateCount: number;
}

interface BackupPhotoRecord {
  fileName: string;
  mimeType: string;
  width: number;
  height: number;
  sha256Hash: string;
  createdAt: number;
  dataBase64: string;
}

interface VaultBackupEnvelope {
  app: 'SmartCalculator';
  version: 1;
  encrypted: boolean;
  createdAt: number;
  saltBase64?: string;
  ivBase64?: string;
  ciphertextBase64?: string;
  photos?: BackupPhotoRecord[];
}

export function getSecretCode(): string {
  try {
    const saved = localStorage.getItem(SECRET_CODE_KEY);
    if (saved && /^\d{4,12}$/.test(saved)) {
      return saved;
    }
  } catch {
    // Fallback to default
  }
  return DEFAULT_SECRET_CODE;
}

export function setSecretCode(code: string): void {
  if (!/^\d{4,12}$/.test(code)) {
    throw new Error('Secret code must be 4 to 12 digits.');
  }
  localStorage.setItem(SECRET_CODE_KEY, code);
}

export function getSavedTheme(): 'dark' | 'light' {
  try {
    const saved = localStorage.getItem(THEME_KEY);
    if (saved === 'light' || saved === 'dark') return saved;
  } catch {
    // Ignore storage access errors
  }
  return 'dark';
}

export function saveTheme(theme: 'dark' | 'light'): void {
  try {
    localStorage.setItem(THEME_KEY, theme);
  } catch {
    // Ignore storage access errors
  }
}

function openVaultDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_PHOTOS)) {
        const store = db.createObjectStore(STORE_PHOTOS, { keyPath: 'id' });
        store.createIndex('sha256Hash', 'sha256Hash', { unique: true });
        store.createIndex('createdAt', 'createdAt', { unique: false });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error('Failed to open private storage.'));
  });
}

export async function getAllVaultPhotos(): Promise<StoredVaultPhoto[]> {
  const db = await openVaultDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_PHOTOS, 'readonly');
    const store = tx.objectStore(STORE_PHOTOS);
    const req = store.getAll();
    req.onsuccess = () => {
      const items = (req.result as StoredVaultPhoto[]) ?? [];
      items.sort((a, b) => b.createdAt - a.createdAt);
      resolve(items);
    };
    req.onerror = () => reject(req.error ?? new Error('Failed to read private photos.'));
    tx.oncomplete = () => db.close();
  });
}

export async function computeBufferSha256(buffer: ArrayBuffer): Promise<string> {
  if (typeof crypto !== 'undefined' && crypto.subtle) {
    const digest = await crypto.subtle.digest('SHA-256', buffer);
    return Array.from(new Uint8Array(digest))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  }
  // Fallback deterministic fingerprint if crypto.subtle is unavailable
  const bytes = new Uint8Array(buffer);
  let h1 = 0x811c9dc5;
  let h2 = 0x9e3779b9;
  for (let i = 0; i < bytes.length; i++) {
    h1 ^= bytes[i];
    h1 = Math.imul(h1, 0x01000193);
    h2 ^= bytes[i] + i;
    h2 = Math.imul(h2, 0x85ebca6b);
  }
  return `${(h1 >>> 0).toString(16).padStart(8, '0')}${(h2 >>> 0).toString(16).padStart(8, '0')}-${bytes.length}`;
}

function measureImageDimensions(url: string): Promise<{ width: number; height: number }> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => resolve({ width: img.naturalWidth, height: img.naturalHeight });
    img.onerror = () => resolve({ width: 0, height: 0 });
    img.src = url;
  });
}

export async function prepareStagedPhotos(
  files: FileList | File[],
  existingHashes: Set<string>
): Promise<StagedPhotoPreview[]> {
  const fileArray = Array.from(files).filter((f) => f.type.startsWith('image/'));
  const seenInBatch = new Set<string>();
  const staged: StagedPhotoPreview[] = [];

  for (const file of fileArray) {
    const buffer = await file.arrayBuffer();
    const sha256Hash = await computeBufferSha256(buffer);
    const isDuplicate = existingHashes.has(sha256Hash) || seenInBatch.has(sha256Hash);
    seenInBatch.add(sha256Hash);

    const previewUrl = URL.createObjectURL(new Blob([buffer], { type: file.type || 'image/jpeg' }));
    const { width, height } = await measureImageDimensions(previewUrl);

    staged.push({
      tempId: `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
      file,
      previewUrl,
      fileName: file.name || `photo_${Date.now()}.jpg`,
      mimeType: file.type || 'image/jpeg',
      sizeBytes: file.size,
      width,
      height,
      sha256Hash,
      isDuplicate,
      buffer,
    });
  }

  return staged;
}

export async function saveStagedPhotosToVault(staged: StagedPhotoPreview[]): Promise<ImportSummary> {
  const existing = await getAllVaultPhotos();
  const existingHashes = new Set(existing.map((p) => p.sha256Hash));

  const toInsert: StoredVaultPhoto[] = [];
  let duplicateCount = 0;

  for (const item of staged) {
    if (existingHashes.has(item.sha256Hash)) {
      duplicateCount++;
      continue;
    }
    existingHashes.add(item.sha256Hash);
    toInsert.push({
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
      fileName: item.fileName,
      mimeType: item.mimeType,
      sizeBytes: item.sizeBytes,
      width: item.width,
      height: item.height,
      sha256Hash: item.sha256Hash,
      createdAt: Date.now() + toInsert.length,
      data: item.buffer,
    });
  }

  if (toInsert.length > 0) {
    const db = await openVaultDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_PHOTOS, 'readwrite');
      const store = tx.objectStore(STORE_PHOTOS);
      for (const record of toInsert) {
        store.add(record);
      }
      tx.oncomplete = () => {
        db.close();
        resolve();
      };
      tx.onerror = () => {
        db.close();
        reject(tx.error ?? new Error('Failed to save photos to private vault.'));
      };
    });
  }

  return {
    savedCount: toInsert.length,
    duplicateCount,
  };
}

export async function deleteVaultPhotosByIds(ids: string[]): Promise<void> {
  if (ids.length === 0) return;
  const db = await openVaultDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_PHOTOS, 'readwrite');
    const store = tx.objectStore(STORE_PHOTOS);
    for (const id of ids) {
      store.delete(id);
    }
    tx.oncomplete = () => {
      db.close();
      resolve();
    };
    tx.onerror = () => {
      db.close();
      reject(tx.error ?? new Error('Failed to delete selected photos.'));
    };
  });
}

export async function deleteAllVaultPhotos(): Promise<void> {
  const db = await openVaultDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_PHOTOS, 'readwrite');
    const store = tx.objectStore(STORE_PHOTOS);
    store.clear();
    tx.oncomplete = () => {
      db.close();
      resolve();
    };
    tx.onerror = () => {
      db.close();
      reject(tx.error ?? new Error('Failed to clear vault.'));
    };
  });
}

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  const chunkSize = 0x8000;
  let binary = '';
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
}

async function deriveAesKey(passphrase: string, salt: Uint8Array): Promise<CryptoKey> {
  const enc = new TextEncoder();
  const baseKey = await crypto.subtle.importKey(
    'raw',
    enc.encode(passphrase),
    'PBKDF2',
    false,
    ['deriveKey']
  );
  return crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: salt as unknown as BufferSource,
      iterations: 100000,
      hash: 'SHA-256',
    },
    baseKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

export async function buildVaultBackupBlob(passphrase?: string): Promise<{ blob: Blob; count: number }> {
  const photos = await getAllVaultPhotos();
  const records: BackupPhotoRecord[] = photos.map((p) => ({
    fileName: p.fileName,
    mimeType: p.mimeType,
    width: p.width,
    height: p.height,
    sha256Hash: p.sha256Hash,
    createdAt: p.createdAt,
    dataBase64: arrayBufferToBase64(p.data),
  }));

  let envelope: VaultBackupEnvelope;
  const trimmedPass = passphrase?.trim();

  if (trimmedPass && typeof crypto !== 'undefined' && crypto.subtle) {
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const key = await deriveAesKey(trimmedPass, salt);
    const plaintext = new TextEncoder().encode(JSON.stringify(records));
    const encryptedBuf = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      key,
      plaintext
    );

    envelope = {
      app: 'SmartCalculator',
      version: 1,
      encrypted: true,
      createdAt: Date.now(),
      saltBase64: arrayBufferToBase64(salt.buffer),
      ivBase64: arrayBufferToBase64(iv.buffer),
      ciphertextBase64: arrayBufferToBase64(encryptedBuf),
    };
  } else {
    envelope = {
      app: 'SmartCalculator',
      version: 1,
      encrypted: false,
      createdAt: Date.now(),
      photos: records,
    };
  }

  return {
    blob: new Blob([JSON.stringify(envelope, null, 2)], { type: 'application/json' }),
    count: records.length,
  };
}

export async function inspectBackupRequiresPassphrase(file: File): Promise<boolean> {
  const text = await file.text();
  const parsed = JSON.parse(text) as Partial<VaultBackupEnvelope>;
  if (parsed.app !== 'SmartCalculator' || parsed.version !== 1) {
    throw new Error('Invalid Smart Calculator backup file.');
  }
  return Boolean(parsed.encrypted);
}

export async function restoreVaultFromBackupFile(
  file: File,
  passphrase?: string
): Promise<ImportSummary> {
  const text = await file.text();
  const parsed = JSON.parse(text) as VaultBackupEnvelope;

  if (parsed.app !== 'SmartCalculator' || parsed.version !== 1) {
    throw new Error('Unrecognized backup format.');
  }

  let records: BackupPhotoRecord[];
  if (parsed.encrypted) {
    if (!passphrase?.trim()) {
      throw new Error('This backup is encrypted. Please enter your backup passphrase.');
    }
    if (!parsed.saltBase64 || !parsed.ivBase64 || !parsed.ciphertextBase64) {
      throw new Error('Corrupted encrypted backup metadata.');
    }
    const salt = new Uint8Array(base64ToArrayBuffer(parsed.saltBase64));
    const iv = new Uint8Array(base64ToArrayBuffer(parsed.ivBase64));
    const ciphertext = base64ToArrayBuffer(parsed.ciphertextBase64);
    const key = await deriveAesKey(passphrase.trim(), salt);
    try {
      const decrypted = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, ciphertext);
      records = JSON.parse(new TextDecoder().decode(decrypted)) as BackupPhotoRecord[];
    } catch {
      throw new Error('Incorrect passphrase or corrupted backup file.');
    }
  } else {
    records = parsed.photos ?? [];
  }

  const existing = await getAllVaultPhotos();
  const existingHashes = new Set(existing.map((p) => p.sha256Hash));
  const toInsert: StoredVaultPhoto[] = [];
  let duplicateCount = 0;

  for (const rec of records) {
    const data = base64ToArrayBuffer(rec.dataBase64);
    const verifiedHash = await computeBufferSha256(data);
    if (existingHashes.has(verifiedHash)) {
      duplicateCount++;
      continue;
    }
    existingHashes.add(verifiedHash);
    toInsert.push({
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
      fileName: rec.fileName || 'restored_photo.jpg',
      mimeType: rec.mimeType || 'image/jpeg',
      sizeBytes: data.byteLength,
      width: rec.width || 0,
      height: rec.height || 0,
      sha256Hash: verifiedHash,
      createdAt: rec.createdAt || Date.now(),
      data,
    });
  }

  if (toInsert.length > 0) {
    const db = await openVaultDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_PHOTOS, 'readwrite');
      const store = tx.objectStore(STORE_PHOTOS);
      for (const item of toInsert) {
        store.add(item);
      }
      tx.oncomplete = () => {
        db.close();
        resolve();
      };
      tx.onerror = () => {
        db.close();
        reject(tx.error ?? new Error('Failed to write restored photos.'));
      };
    });
  }

  return {
    savedCount: toInsert.length,
    duplicateCount,
  };
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}
