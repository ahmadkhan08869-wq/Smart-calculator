package com.smartcalculator.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Backspace
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun CalculatorScreen(
    state: CalculatorState,
    isDarkTheme: Boolean,
    onToggleTheme: () -> Unit,
    onDigit: (String) -> Unit,
    onDecimal: () -> Unit,
    onToggleSign: () -> Unit,
    onPercent: () -> Unit,
    onOperator: (CalcOperator) -> Unit,
    onClear: () -> Unit,
    onBackspace: () -> Unit,
    onEquals: () -> Unit
) {
    val colors = MaterialTheme.colorScheme

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .safeDrawingPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Smart Calculator",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = colors.onBackground
            )
            IconButton(onClick = onToggleTheme) {
                Icon(
                    imageVector = if (isDarkTheme) Icons.Outlined.LightMode else Icons.Outlined.DarkMode,
                    contentDescription = "Toggle theme",
                    tint = colors.onSurfaceVariant
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 8.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.Bottom,
            horizontalAlignment = Alignment.End
        ) {
            Text(
                text = state.expressionDisplay,
                fontSize = 20.sp,
                fontFamily = FontFamily.Monospace,
                color = colors.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.End
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = state.currentDisplay,
                fontSize = if (state.currentDisplay.length > 10) 40.sp else 56.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = if (state.isError) colors.error else colors.onBackground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.End
            )
        }

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CalcKey("C", isAction = true, modifier = Modifier.weight(1f), onClick = onClear)
                CalcIconKey(
                    icon = Icons.AutoMirrored.Outlined.Backspace,
                    contentDescription = "Backspace",
                    modifier = Modifier.weight(1f),
                    onClick = onBackspace
                )
                CalcKey("%", isAction = true, modifier = Modifier.weight(1f), onClick = onPercent)
                CalcKey("÷", isOperator = true, modifier = Modifier.weight(1f)) {
                    onOperator(CalcOperator.DIVIDE)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CalcKey("7", modifier = Modifier.weight(1f)) { onDigit("7") }
                CalcKey("8", modifier = Modifier.weight(1f)) { onDigit("8") }
                CalcKey("9", modifier = Modifier.weight(1f)) { onDigit("9") }
                CalcKey("×", isOperator = true, modifier = Modifier.weight(1f)) {
                    onOperator(CalcOperator.MULTIPLY)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CalcKey("4", modifier = Modifier.weight(1f)) { onDigit("4") }
                CalcKey("5", modifier = Modifier.weight(1f)) { onDigit("5") }
                CalcKey("6", modifier = Modifier.weight(1f)) { onDigit("6") }
                CalcKey("−", isOperator = true, modifier = Modifier.weight(1f)) {
                    onOperator(CalcOperator.SUBTRACT)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CalcKey("1", modifier = Modifier.weight(1f)) { onDigit("1") }
                CalcKey("2", modifier = Modifier.weight(1f)) { onDigit("2") }
                CalcKey("3", modifier = Modifier.weight(1f)) { onDigit("3") }
                CalcKey("+", isOperator = true, modifier = Modifier.weight(1f)) {
                    onOperator(CalcOperator.ADD)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CalcKey("±", modifier = Modifier.weight(1f), onClick = onToggleSign)
                CalcKey("0", modifier = Modifier.weight(1f)) { onDigit("0") }
                CalcKey(".", modifier = Modifier.weight(1f), onClick = onDecimal)
                CalcKey("=", isEquals = true, modifier = Modifier.weight(1f), onClick = onEquals)
            }
        }
    }
}

@Composable
private fun CalcKey(
    label: String,
    modifier: Modifier = Modifier,
    isOperator: Boolean = false,
    isAction: Boolean = false,
    isEquals: Boolean = false,
    onClick: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    val bgColor: Color
    val textColor: Color
    when {
        isEquals -> {
            bgColor = colors.primary
            textColor = colors.onPrimary
        }
        isOperator -> {
            bgColor = colors.primary.copy(alpha = 0.14f)
            textColor = colors.primary
        }
        isAction -> {
            bgColor = colors.secondary
            textColor = colors.onSecondary
        }
        else -> {
            bgColor = colors.surface
            textColor = colors.onSurface
        }
    }

    Box(
        modifier = modifier
            .aspectRatio(1.15f)
            .clip(RoundedCornerShape(18.dp))
            .background(bgColor)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 24.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = FontFamily.Monospace,
            color = textColor
        )
    }
}

@Composable
private fun CalcIconKey(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val colors = MaterialTheme.colorScheme
    Box(
        modifier = modifier
            .aspectRatio(1.15f)
            .clip(RoundedCornerShape(18.dp))
            .background(colors.secondary)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = colors.onSecondary
        )
    }
}
