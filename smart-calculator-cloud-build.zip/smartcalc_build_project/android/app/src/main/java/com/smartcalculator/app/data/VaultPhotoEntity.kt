package com.smartcalculator.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "vault_photos",
    indices = [Index(value = ["sha256Hash"], unique = true)]
)
data class VaultPhotoEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val fileName: String,
    val internalPath: String,
    val sha256Hash: String,
    val mimeType: String,
    val sizeBytes: Long,
    val width: Int,
    val height: Int,
    val createdAt: Long = System.currentTimeMillis()
)
