package com.smartcalculator.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface VaultPhotoDao {

    @Query("SELECT * FROM vault_photos ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<VaultPhotoEntity>>

    @Query("SELECT * FROM vault_photos ORDER BY createdAt DESC")
    suspend fun getAllOnce(): List<VaultPhotoEntity>

    @Query("SELECT EXISTS(SELECT 1 FROM vault_photos WHERE sha256Hash = :hash)")
    suspend fun existsByHash(hash: String): Boolean

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(photos: List<VaultPhotoEntity>): List<Long>

    @Query("DELETE FROM vault_photos WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<Long>)

    @Query("DELETE FROM vault_photos")
    suspend fun deleteAll()
}
