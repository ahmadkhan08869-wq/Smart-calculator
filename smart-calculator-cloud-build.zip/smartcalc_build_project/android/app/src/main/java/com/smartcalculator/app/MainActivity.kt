package com.smartcalculator.app

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.smartcalculator.app.ui.CalculatorScreen
import com.smartcalculator.app.ui.VaultContainerScreen
import com.smartcalculator.app.ui.VaultViewModel
import com.smartcalculator.app.ui.theme.SmartCalculatorTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val viewModel: VaultViewModel = viewModel()
            val calcState by viewModel.calcState.collectAsState()
            val isVaultUnlocked by viewModel.isVaultUnlocked.collectAsState()
            val vaultSection by viewModel.vaultSection.collectAsState()
            val isDarkTheme by viewModel.isDarkTheme.collectAsState()
            val savedPhotos by viewModel.savedPhotos.collectAsState()
            val pendingImportUris by viewModel.pendingImportUris.collectAsState()
            val statusBanner by viewModel.statusBanner.collectAsState()
            val isBusy by viewModel.isBusy.collectAsState()

            // Prevent screenshots and Recents preview exposure while the hidden vault is open
            LaunchedEffect(isVaultUnlocked) {
                if (isVaultUnlocked) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
            }

            SmartCalculatorTheme(darkTheme = isDarkTheme) {
                if (!isVaultUnlocked) {
                    CalculatorScreen(
                        state = calcState,
                        isDarkTheme = isDarkTheme,
                        onToggleTheme = viewModel::toggleTheme,
                        onDigit = viewModel::onDigit,
                        onDecimal = viewModel::onDecimal,
                        onToggleSign = viewModel::onToggleSign,
                        onPercent = viewModel::onPercent,
                        onOperator = viewModel::onOperator,
                        onClear = viewModel::onClear,
                        onBackspace = viewModel::onBackspace,
                        onEquals = viewModel::onEquals
                    )
                } else {
                    VaultContainerScreen(
                        section = vaultSection,
                        savedPhotos = savedPhotos,
                        pendingImportUris = pendingImportUris,
                        statusBanner = statusBanner,
                        isBusy = isBusy,
                        isDarkTheme = isDarkTheme,
                        onToggleTheme = viewModel::toggleTheme,
                        onNavigate = viewModel::navigateTo,
                        onPhotosPicked = viewModel::onPhotosPicked,
                        onAcceptImport = viewModel::acceptPendingImport,
                        onCancelImport = viewModel::cancelPendingImport,
                        onDeleteSelected = viewModel::deleteSelectedPhotos,
                        onDeleteAll = viewModel::deleteAllPhotos,
                        onUpdateSecretCode = viewModel::updateSecretCode,
                        onExportBackup = viewModel::exportBackup,
                        onRestoreBackup = viewModel::restoreBackup,
                        onDismissBanner = viewModel::clearBanner,
                        onLockVault = viewModel::lockVault
                    )
                }
            }
        }
    }
}
