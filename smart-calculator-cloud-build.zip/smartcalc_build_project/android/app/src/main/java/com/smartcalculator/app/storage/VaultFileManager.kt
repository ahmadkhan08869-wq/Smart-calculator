package com.smartcalculator.app.storage

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import com.smartcalculator.app.data.VaultPhotoDao
import com.smartcalculator.app.data.VaultPhotoEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class ImportResult(
    val savedCount: Int,
    val duplicateCount: Int
)

class VaultFileManager(
    private val context: Context,
    private val dao: VaultPhotoDao
) {
    private val vaultDir: File by lazy {
        File(context.filesDir, "private_vault").apply {
            if (!exists()) mkdirs()
            // Ensure Android MediaStore never indexes private vault files
            val nomedia = File(this, ".nomedia")
            if (!nomedia.exists()) nomedia.createNewFile()
        }
    }

    suspend fun importPhotos(uris: List<Uri>): ImportResult = withContext(Dispatchers.IO) {
        var saved = 0
        var duplicates = 0
        val newEntities = mutableListOf<VaultPhotoEntity>()
        val seenHashesInBatch = mutableSetOf<String>()

        for (uri in uris) {
            val mimeType = context.contentResolver.getType(uri) ?: "image/jpeg"
            val displayName = queryDisplayName(uri) ?: "photo_${System.currentTimeMillis()}.jpg"
            val tempFile = File(context.cacheDir, "tmp_${UUID.randomUUID()}")

            try {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(tempFile).use { output ->
                        input.copyTo(output)
                    }
                } ?: continue

                val hash = computeSha256(tempFile)
                if (hash in seenHashesInBatch || dao.existsByHash(hash)) {
                    duplicates++
                    tempFile.delete()
                    continue
                }
                seenHashesInBatch.add(hash)

                val (width, height) = decodeBounds(tempFile)
                val ext = extensionForMime(mimeType, displayName)
                val destFile = File(vaultDir, "${UUID.randomUUID()}.$ext")
                tempFile.copyTo(destFile, overwrite = true)
                tempFile.delete()

                newEntities.add(
                    VaultPhotoEntity(
                        fileName = displayName,
                        internalPath = destFile.absolutePath,
                        sha256Hash = hash,
                        mimeType = mimeType,
                        sizeBytes = destFile.length(),
                        width = width,
                        height = height
                    )
                )
                saved++
            } catch (_: Exception) {
                tempFile.delete()
            }
        }

        if (newEntities.isNotEmpty()) {
            dao.insertAll(newEntities)
        }

        ImportResult(savedCount = saved, duplicateCount = duplicates)
    }

    suspend fun deletePhotos(photos: List<VaultPhotoEntity>) = withContext(Dispatchers.IO) {
        photos.forEach { photo ->
            runCatching { File(photo.internalPath).delete() }
        }
        dao.deleteByIds(photos.map { it.id })
    }

    suspend fun deleteAllPhotos() = withContext(Dispatchers.IO) {
        val all = dao.getAllOnce()
        all.forEach { photo ->
            runCatching { File(photo.internalPath).delete() }
        }
        dao.deleteAll()
    }

    suspend fun exportBackupToUri(destinationUri: Uri): Int = withContext(Dispatchers.IO) {
        val photos = dao.getAllOnce()
        val manifestArray = JSONArray()

        context.contentResolver.openOutputStream(destinationUri)?.use { outStream ->
            ZipOutputStream(BufferedOutputStream(outStream)).use { zip ->
                photos.forEachIndexed { index, photo ->
                    val file = File(photo.internalPath)
                    if (!file.exists()) return@forEachIndexed

                    val entryName = "photos/${index}_${photo.sha256Hash.take(12)}_${photo.fileName}"
                    zip.putNextEntry(ZipEntry(entryName))
                    FileInputStream(file).use { it.copyTo(zip) }
                    zip.closeEntry()

                    manifestArray.put(
                        JSONObject().apply {
                            put("entryName", entryName)
                            put("fileName", photo.fileName)
                            put("sha256Hash", photo.sha256Hash)
                            put("mimeType", photo.mimeType)
                            put("width", photo.width)
                            put("height", photo.height)
                            put("createdAt", photo.createdAt)
                        }
                    )
                }

                zip.putNextEntry(ZipEntry("manifest.json"))
                zip.write(manifestArray.toString(2).toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
        }
        photos.size
    }

    suspend fun restoreBackupFromUri(sourceUri: Uri): ImportResult = withContext(Dispatchers.IO) {
        var restored = 0
        var duplicates = 0
        val tempExtractDir = File(context.cacheDir, "restore_${UUID.randomUUID()}").apply { mkdirs() }

        try {
            var manifestJson: String? = null
            context.contentResolver.openInputStream(sourceUri)?.use { inStream ->
                ZipInputStream(BufferedInputStream(inStream)).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        val outFile = File(tempExtractDir, entry.name)
                        if (!outFile.canonicalPath.startsWith(tempExtractDir.canonicalPath)) {
                            throw SecurityException("Invalid zip entry path")
                        }
                        if (entry.name == "manifest.json") {
                            manifestJson = zip.readBytes().toString(Charsets.UTF_8)
                        } else if (!entry.isDirectory) {
                            outFile.parentFile?.mkdirs()
                            FileOutputStream(outFile).use { zip.copyTo(it) }
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
            }

            val manifest = JSONArray(manifestJson ?: "[]")
            val entities = mutableListOf<VaultPhotoEntity>()

            for (i in 0 until manifest.length()) {
                val item = manifest.getJSONObject(i)
                val entryName = item.getString("entryName")
                val extracted = File(tempExtractDir, entryName)
                if (!extracted.exists()) continue

                val hash = computeSha256(extracted)
                if (dao.existsByHash(hash)) {
                    duplicates++
                    continue
                }

                val fileName = item.optString("fileName", "restored_$i.jpg")
                val mimeType = item.optString("mimeType", "image/jpeg")
                val ext = extensionForMime(mimeType, fileName)
                val destFile = File(vaultDir, "${UUID.randomUUID()}.$ext")
                extracted.copyTo(destFile, overwrite = true)

                val (w, h) = decodeBounds(destFile)
                entities.add(
                    VaultPhotoEntity(
                        fileName = fileName,
                        internalPath = destFile.absolutePath,
                        sha256Hash = hash,
                        mimeType = mimeType,
                        sizeBytes = destFile.length(),
                        width = w,
                        height = h,
                        createdAt = item.optLong("createdAt", System.currentTimeMillis())
                    )
                )
                restored++
            }

            if (entities.isNotEmpty()) {
                dao.insertAll(entities)
            }
        } finally {
            tempExtractDir.deleteRecursively()
        }

        ImportResult(savedCount = restored, duplicateCount = duplicates)
    }

    private fun queryDisplayName(uri: Uri): String? {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) return cursor.getString(idx)
                }
            }
        return null
    }

    private fun computeSha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(8192)
            var bytesRead: Int
            while (input.read(buffer).also { bytesRead = it } != -1) {
                digest.update(buffer, 0, bytesRead)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun decodeBounds(file: File): Pair<Int, Int> {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, opts)
        return opts.outWidth.coerceAtLeast(0) to opts.outHeight.coerceAtLeast(0)
    }

    private fun extensionForMime(mime: String, fallbackName: String): String {
        return when (mime.lowercase()) {
            "image/png" -> "png"
            "image/webp" -> "webp"
            "image/gif" -> "gif"
            "image/heic", "image/heif" -> "heic"
            else -> fallbackName.substringAfterLast('.', "jpg").lowercase()
        }
    }
}
