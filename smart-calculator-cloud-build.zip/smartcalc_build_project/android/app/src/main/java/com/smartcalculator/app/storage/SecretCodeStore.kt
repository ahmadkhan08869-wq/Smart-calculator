package com.smartcalculator.app.storage

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class SecretCodeStore(context: Context) {

    private val masterKey = MasterKey.Builder(context.applicationContext)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context.applicationContext,
        PREFS_NAME,
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun getSecretCode(): String {
        return prefs.getString(KEY_SECRET_CODE, DEFAULT_SECRET_CODE) ?: DEFAULT_SECRET_CODE
    }

    fun updateSecretCode(newCode: String) {
        require(newCode.length in 4..12 && newCode.all { it.isDigit() }) {
            "Secret code must be 4 to 12 digits."
        }
        prefs.edit().putString(KEY_SECRET_CODE, newCode).apply()
    }

    fun isDarkTheme(): Boolean {
        return prefs.getBoolean(KEY_DARK_THEME, true)
    }

    fun setDarkTheme(dark: Boolean) {
        prefs.edit().putBoolean(KEY_DARK_THEME, dark).apply()
    }

    companion object {
        private const val PREFS_NAME = "smart_calc_secure_prefs"
        private const val KEY_SECRET_CODE = "vault_secret_code"
        private const val KEY_DARK_THEME = "ui_dark_theme"
        const val DEFAULT_SECRET_CODE = "859115"
    }
}
