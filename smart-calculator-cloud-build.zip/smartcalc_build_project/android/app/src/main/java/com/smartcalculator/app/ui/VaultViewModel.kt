package com.smartcalculator.app.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.smartcalculator.app.data.VaultDatabase
import com.smartcalculator.app.data.VaultPhotoEntity
import com.smartcalculator.app.storage.SecretCodeStore
import com.smartcalculator.app.storage.VaultFileManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class VaultSection {
    MENU,
    PREVIEW_IMPORT,
    GALLERY,
    DELETE_PHOTOS,
    CHANGE_CODE
}

class VaultViewModel(application: Application) : AndroidViewModel(application) {

    private val database = VaultDatabase.getInstance(application)
    private val dao = database.vaultPhotoDao()
    private val fileManager = VaultFileManager(application, dao)
    private val secretStore = SecretCodeStore(application)

    private val _calcState = MutableStateFlow(CalculatorState())
    val calcState: StateFlow<CalculatorState> = _calcState.asStateFlow()

    private val _isVaultUnlocked = MutableStateFlow(false)
    val isVaultUnlocked: StateFlow<Boolean> = _isVaultUnlocked.asStateFlow()

    private val _vaultSection = MutableStateFlow(VaultSection.MENU)
    val vaultSection: StateFlow<VaultSection> = _vaultSection.asStateFlow()

    private val _isDarkTheme = MutableStateFlow(secretStore.isDarkTheme())
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    private val _pendingImportUris = MutableStateFlow<List<Uri>>(emptyList())
    val pendingImportUris: StateFlow<List<Uri>> = _pendingImportUris.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    val savedPhotos: StateFlow<List<VaultPhotoEntity>> = dao.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun toggleTheme() {
        val next = !_isDarkTheme.value
        _isDarkTheme.value = next
        secretStore.setDarkTheme(next)
    }

    fun onDigit(digit: String) {
        _calcState.value = CalculatorEngine.appendDigit(_calcState.value, digit)
    }

    fun onDecimal() {
        _calcState.value = CalculatorEngine.appendDecimal(_calcState.value)
    }

    fun onToggleSign() {
        _calcState.value = CalculatorEngine.toggleSign(_calcState.value)
    }

    fun onPercent() {
        _calcState.value = CalculatorEngine.applyPercent(_calcState.value)
    }

    fun onOperator(op: CalcOperator) {
        _calcState.value = CalculatorEngine.chooseOperator(_calcState.value, op)
    }

    fun onClear() {
        _calcState.value = CalculatorEngine.clearAll()
    }

    fun onBackspace() {
        _calcState.value = CalculatorEngine.backspace(_calcState.value)
    }

    fun onEquals() {
        val secret = secretStore.getSecretCode()
        when (val result = CalculatorEngine.pressEquals(_calcState.value, secret)) {
            is CalcActionResult.UnlockVault -> {
                _calcState.value = CalculatorEngine.clearAll()
                _vaultSection.value = VaultSection.MENU
                _isVaultUnlocked.value = true
            }
            is CalcActionResult.Updated -> {
                _calcState.value = result.state
            }
        }
    }

    fun lockVault() {
        _isVaultUnlocked.value = false
        _vaultSection.value = VaultSection.MENU
        _pendingImportUris.value = emptyList()
        _statusBanner.value = null
    }

    fun navigateTo(section: VaultSection) {
        _statusBanner.value = null
        _vaultSection.value = section
    }

    fun onPhotosPicked(uris: List<Uri>) {
        if (uris.isEmpty()) return
        _pendingImportUris.value = uris
        _vaultSection.value = VaultSection.PREVIEW_IMPORT
    }

    fun cancelPendingImport() {
        _pendingImportUris.value = emptyList()
        _vaultSection.value = VaultSection.MENU
    }

    fun acceptPendingImport() {
        val uris = _pendingImportUris.value
        if (uris.isEmpty()) return
        viewModelScope.launch {
            _isBusy.value = true
            val result = fileManager.importPhotos(uris)
            _pendingImportUris.value = emptyList()
            _isBusy.value = false
            _vaultSection.value = VaultSection.GALLERY
            _statusBanner.value = buildString {
                append("${result.savedCount} photo(s) saved privately.")
                if (result.duplicateCount > 0) {
                    append(" ${result.duplicateCount} duplicate(s) skipped.")
                }
            }
        }
    }

    fun deleteSelectedPhotos(photos: List<VaultPhotoEntity>) {
        if (photos.isEmpty()) return
        viewModelScope.launch {
            _isBusy.value = true
            fileManager.deletePhotos(photos)
            _isBusy.value = false
            _statusBanner.value = "${photos.size} photo(s) deleted permanently."
        }
    }

    fun deleteAllPhotos() {
        viewModelScope.launch {
            _isBusy.value = true
            fileManager.deleteAllPhotos()
            _isBusy.value = false
            _statusBanner.value = "All photos deleted permanently."
        }
    }

    fun updateSecretCode(current: String, next: String, confirm: String): String? {
        if (current != secretStore.getSecretCode()) {
            return "Current secret code is incorrect."
        }
        if (next.length !in 4..12 || !next.all { it.isDigit() }) {
            return "New code must be 4 to 12 digits."
        }
        if (next != confirm) {
            return "New codes do not match."
        }
        secretStore.updateSecretCode(next)
        _statusBanner.value = "Secret code updated successfully."
        _vaultSection.value = VaultSection.MENU
        return null
    }

    fun exportBackup(destinationUri: Uri) {
        viewModelScope.launch {
            _isBusy.value = true
            val count = fileManager.exportBackupToUri(destinationUri)
            _isBusy.value = false
            _statusBanner.value = "Exported $count photo(s) to backup archive."
        }
    }

    fun restoreBackup(sourceUri: Uri) {
        viewModelScope.launch {
            _isBusy.value = true
            val result = fileManager.restoreBackupFromUri(sourceUri)
            _isBusy.value = false
            _statusBanner.value = buildString {
                append("Restored ${result.savedCount} photo(s).")
                if (result.duplicateCount > 0) {
                    append(" ${result.duplicateCount} duplicate(s) skipped.")
                }
            }
        }
    }

    fun clearBanner() {
        _statusBanner.value = null
    }
}
