package com.smartcalculator.app.ui

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode

enum class CalcOperator(val symbol: String) {
    ADD("+"),
    SUBTRACT("−"),
    MULTIPLY("×"),
    DIVIDE("÷")
}

data class CalculatorState(
    val currentDisplay: String = "0",
    val expressionDisplay: String = "",
    val previousOperand: String? = null,
    val pendingOperator: CalcOperator? = null,
    val shouldResetInput: Boolean = false,
    val isError: Boolean = false
)

sealed class CalcActionResult {
    data class Updated(val state: CalculatorState) : CalcActionResult()
    data object UnlockVault : CalcActionResult()
}

object CalculatorEngine {

    fun appendDigit(state: CalculatorState, digit: String): CalculatorState {
        if (state.isError || state.shouldResetInput) {
            return state.copy(
                currentDisplay = digit,
                shouldResetInput = false,
                isError = false
            )
        }
        val next = if (state.currentDisplay == "0") digit else state.currentDisplay + digit
        if (next.replace("-", "").replace(".", "").length > 15) return state
        return state.copy(currentDisplay = next)
    }

    fun appendDecimal(state: CalculatorState): CalculatorState {
        if (state.isError || state.shouldResetInput) {
            return state.copy(
                currentDisplay = "0.",
                shouldResetInput = false,
                isError = false
            )
        }
        if (state.currentDisplay.contains(".")) return state
        return state.copy(currentDisplay = state.currentDisplay + ".")
    }

    fun toggleSign(state: CalculatorState): CalculatorState {
        if (state.isError || state.currentDisplay == "0") return state
        val toggled = if (state.currentDisplay.startsWith("-")) {
            state.currentDisplay.removePrefix("-")
        } else {
            "-${state.currentDisplay}"
        }
        return state.copy(currentDisplay = toggled)
    }

    fun applyPercent(state: CalculatorState): CalculatorState {
        if (state.isError) return state
        val current = state.currentDisplay.toBigDecimalOrNull() ?: return state
        val result = if (state.previousOperand != null &&
            (state.pendingOperator == CalcOperator.ADD || state.pendingOperator == CalcOperator.SUBTRACT)
        ) {
            val base = state.previousOperand.toBigDecimalOrNull() ?: BigDecimal.ZERO
            base.multiply(current).divide(BigDecimal(100), MathContext.DECIMAL64)
        } else {
            current.divide(BigDecimal(100), MathContext.DECIMAL64)
        }
        return state.copy(
            currentDisplay = formatBigDecimal(result),
            shouldResetInput = false
        )
    }

    fun chooseOperator(state: CalculatorState, op: CalcOperator): CalculatorState {
        if (state.isError) return state
        val working = if (state.pendingOperator != null && !state.shouldResetInput) {
            evaluateBinary(state)
        } else {
            state
        }
        if (working.isError) return working
        return working.copy(
            previousOperand = working.currentDisplay,
            pendingOperator = op,
            expressionDisplay = "${working.currentDisplay} ${op.symbol}",
            shouldResetInput = true
        )
    }

    fun pressEquals(state: CalculatorState, secretCode: String): CalcActionResult {
        if (state.pendingOperator == null && state.currentDisplay == secretCode) {
            return CalcActionResult.UnlockVault
        }
        if (state.isError || state.pendingOperator == null || state.previousOperand == null) {
            return CalcActionResult.Updated(state)
        }
        return CalcActionResult.Updated(evaluateBinary(state))
    }

    fun clearAll(): CalculatorState = CalculatorState()

    fun backspace(state: CalculatorState): CalculatorState {
        if (state.isError || state.shouldResetInput) {
            return state.copy(currentDisplay = "0", shouldResetInput = false, isError = false)
        }
        val trimmed = state.currentDisplay.dropLast(1)
        val next = if (trimmed.isEmpty() || trimmed == "-") "0" else trimmed
        return state.copy(currentDisplay = next)
    }

    private fun evaluateBinary(state: CalculatorState): CalculatorState {
        val a = state.previousOperand?.toBigDecimalOrNull() ?: return state
        val b = state.currentDisplay.toBigDecimalOrNull() ?: return state
        val op = state.pendingOperator ?: return state

        val result = when (op) {
            CalcOperator.ADD -> a.add(b, MathContext.DECIMAL64)
            CalcOperator.SUBTRACT -> a.subtract(b, MathContext.DECIMAL64)
            CalcOperator.MULTIPLY -> a.multiply(b, MathContext.DECIMAL64)
            CalcOperator.DIVIDE -> {
                if (b.compareTo(BigDecimal.ZERO) == 0) {
                    return CalculatorState(
                        currentDisplay = "Error",
                        expressionDisplay = "${state.previousOperand} ÷ 0",
                        isError = true,
                        shouldResetInput = true
                    )
                }
                a.divide(b, 12, RoundingMode.HALF_UP)
            }
        }

        return CalculatorState(
            currentDisplay = formatBigDecimal(result),
            expressionDisplay = "",
            previousOperand = null,
            pendingOperator = null,
            shouldResetInput = true,
            isError = false
        )
    }

    private fun formatBigDecimal(value: BigDecimal): String {
        val stripped = value.stripTrailingZeros()
        return if (stripped.scale() <= 0) {
            stripped.toPlainString()
        } else {
            stripped.toPlainString()
        }
    }
}
